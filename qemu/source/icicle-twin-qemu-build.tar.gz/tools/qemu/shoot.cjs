// Drive the spike page in Chromium (Playwright): wait for the shell prompt, type commands, take the
// boot and shell screenshots, print timings as JSON. Each run uses a fresh browser context (service
// worker registration, reload, empty HTTP cache), like a first visit.
//
//   node tools/qemu/shoot.cjs <url> <shots dir or "-"> [runs]
//   node tools/qemu/shoot.cjs http://127.0.0.1:47213/qemu-spike/ docs/shots/qemu-spike 5
const path = require('node:path');
const { chromium } = require(path.resolve(__dirname, '../../node_modules/playwright'));

const url = process.argv[2] ?? 'http://127.0.0.1:47213/qemu-spike/';
const outDir = process.argv[3] ?? 'docs/shots/qemu-spike';
const runs = Number(process.argv[4] ?? 1);

async function run(browser, n) {
  const context = await browser.newContext({ viewport: { width: 1280, height: 760 } });
  const page = await context.newPage();
  page.on('pageerror', (e) => console.error(`[pageerror] ${e.message}`));
  const navStart = Date.now();
  await page.goto(url);
  await page.waitForFunction(() => window.spike?.timings?.['shell prompt'] !== undefined, null, {
    timeout: 300_000,
    polling: 100,
  });
  const result = { run: n, wallToPromptMs: Date.now() - navStart };
  result.timings = await page.evaluate(() => window.spike.timings);
  const logLen = () => page.evaluate(() => window.spike.log.length);
  const until = (needle, from) =>
    page.waitForFunction(([s, f]) => window.spike.log.slice(f).includes(s), [needle, from], { timeout: 60_000, polling: 20 });
  const typeLine = async (line) => {
    await page.keyboard.type(line, { delay: 10 });
    await page.keyboard.press('Enter');
  };

  if (n === 0 && outDir !== '-') {
    await page.waitForTimeout(300);
    await page.screenshot({ path: path.join(outDir, 'boot.png') });
  }
  await page.click('#terminal');

  // Keystroke-to-echo latency: one character, measured until the guest echoes it back.
  let from = await logLen();
  let t = Date.now();
  await page.keyboard.type('x');
  await until('x', from);
  result.keyEchoMs = Date.now() - t;
  await page.keyboard.press('Backspace');

  // Command round trip: Enter on a short command until the next prompt.
  await page.keyboard.type('true');
  from = await logLen();
  t = Date.now();
  await page.keyboard.press('Enter');
  await until('root@icicle-kit-es:', from);
  result.trueRoundTripMs = Date.now() - t;

  // Guest clock vs wall clock over ~10 s.
  from = await logLen();
  const w0 = Date.now();
  await typeLine('cut -d" " -f1 /proc/uptime');
  await until('root@icicle-kit-es:', from + 10);
  const u0 = parseFloat((await page.evaluate((f) => window.spike.log.slice(f), from)).split('\n')[1]);
  await page.waitForTimeout(10_000);
  from = await logLen();
  const w1 = Date.now();
  await typeLine('cut -d" " -f1 /proc/uptime');
  await until('root@icicle-kit-es:', from + 10);
  const u1 = parseFloat((await page.evaluate((f) => window.spike.log.slice(f), from)).split('\n')[1]);
  result.guestSecondsPerWallSecond = +((u1 - u0) / ((w1 - w0) / 1000)).toFixed(3);

  // A CPU-bound guest loop, for a speed figure to compare with the native build.
  from = await logLen();
  await typeLine('time sh -c \'i=0; while [ $i -lt 5000 ]; do i=$((i+1)); done\'');
  await page.waitForFunction(([s, f]) => window.spike.log.slice(f).includes(s), ['real', from], { timeout: 180_000, polling: 50 });
  await until('root@icicle-kit-es:', from + 10);
  result.loop5k = (await page.evaluate((f) => window.spike.log.slice(f), from)).match(/real\s+(\d+m\s*[\d.]+s)/)?.[1];

  if (n === 0 && outDir !== '-') {
    const cmd = async (line) => {
      const f = await logLen();
      await typeLine(line);
      await until('root@icicle-kit-es:', f + line.length);
    };
    await page.keyboard.press('Control+L');
    await page.waitForTimeout(300);
    await cmd('uname -a; head -5 /proc/cpuinfo; ls /sys/class/leds');
    await cmd('echo 1 > /sys/class/leds/led1/brightness; echo 1 > /sys/class/leds/led3/brightness');
    await cmd('devmem 0x20122088 32');
    await page.waitForFunction(() => (window.spike.gpio?.out ?? 0) === 0x50000, null, { timeout: 60_000 });
    await page.waitForTimeout(800);
    await page.screenshot({ path: path.join(outDir, 'shell.png') });
    result.gpio = await page.evaluate(() => window.spike.gpio);
  }
  await context.close();
  return result;
}

(async () => {
  const browser = await chromium.launch();
  const results = [];
  for (let n = 0; n < runs; n++) results.push(await run(browser, n));
  console.log(JSON.stringify(results, null, 1));
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
