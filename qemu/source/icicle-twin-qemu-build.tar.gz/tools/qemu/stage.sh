#!/usr/bin/env bash
# Copy the built QEMU wasm + guest image to where the site serves them (git-ignored) and print the
# download sizes raw / gzip -9 / brotli -q 11.
#
#   WORK=~/qemu-spike bash tools/qemu/stage.sh          # the app's "Real CPU (QEMU)" mode: public/qemu/bin/
#   WORK=~/qemu-spike bash tools/qemu/stage.sh spike    # the standalone spike page: public/qemu-spike/bin/
#
# The app's copy also gets manifest.json: every file with its size and sha256. The app reads it first,
# so it can show a real progress bar and fetch each file as `name?v=<sha256 prefix>`, which keeps a
# browser's cached copy from outliving a rebuild (GitHub Pages caches for 10 minutes).
#
# Files fetched only when needed (not part of the QEMU mode's download) are listed under "lazy": the
# finale's Freedoom pack (tools/qemu/doom/build-doom.sh), fetched when the finale starts the Real CPU.
set -euo pipefail
WORK=${WORK:-$HOME/qemu-spike}
HERE=$(cd "$(dirname "$0")" && pwd)
TARGET=${1:-app}
QEMU_FILES="qemu-system-riscv64.js qemu-system-riscv64.wasm qemu-system-riscv64.worker.js opensbi-riscv64-generic-fw_dynamic.bin"
if [ "$TARGET" = spike ]; then
  DEST=$HERE/../../public/qemu-spike/bin
  FILES="$QEMU_FILES Image icicle-spike.dtb icicle-spike-smp5.dtb"
else
  DEST=$HERE/../../public/qemu/bin
  FILES="$QEMU_FILES Image icicle-twin.dtb"
  LAZY="freedoom-pack.cpio"
fi
LAZY=${LAZY:-}
rm -rf "$DEST"
mkdir -p "$DEST"
for f in $FILES $LAZY; do cp "$WORK/out/$f" "$DEST/$f"; done
command -v brotli >/dev/null || { echo "brotli missing: apt-get install -y brotli" >&2; exit 1; }
printf '%-42s %12s %12s %12s\n' file raw gzip-9 brotli-11
tr=0; tg=0; tb=0
entries=""
for f in $FILES; do
  p=$DEST/$f
  r=$(stat -c %s "$p"); g=$(gzip -9c "$p" | wc -c); b=$(brotli -q 11 -c "$p" | wc -c)
  s=$(sha256sum "$p" | cut -d' ' -f1)
  tr=$((tr + r)); tg=$((tg + g)); tb=$((tb + b))
  printf '%-42s %12d %12d %12d\n' "$f" "$r" "$g" "$b"
  entries="$entries${entries:+,}
    {\"name\": \"$f\", \"bytes\": $r, \"gzip\": $g, \"sha256\": \"$s\"}"
done
printf '%-42s %12d %12d %12d\n' TOTAL "$tr" "$tg" "$tb"
lazy=""
for f in $LAZY; do
  p=$DEST/$f
  r=$(stat -c %s "$p"); g=$(gzip -9c "$p" | wc -c); b=$(brotli -q 11 -c "$p" | wc -c)
  s=$(sha256sum "$p" | cut -d' ' -f1)
  printf '%-42s %12d %12d %12d  (lazy)\n' "$f" "$r" "$g" "$b"
  lazy="$lazy${lazy:+,}
    {\"name\": \"$f\", \"bytes\": $r, \"gzip\": $g, \"sha256\": \"$s\"}"
done
if [ "$TARGET" != spike ]; then
  cat > "$DEST/manifest.json" <<EOF
{
  "format": 1,
  "built": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "boot": "direct",
  "files": [$entries
  ],
  "lazy": [$lazy
  ]
}
EOF
  echo "wrote $DEST/manifest.json"
fi
