// SPDX-License-Identifier: MIT
/*
 * blinky: the Icicle Twin's "test your code before the hardware arrives" program.
 *
 * It uses only the standard Linux interfaces a program on the real Icicle Kit uses:
 *  - the four user LEDs through the LED class, /sys/class/leds/led1..led4/brightness
 *    (gpio-leds -> gpio-mpfs -> MSS GPIO2 bits 16..19 -> U50 -> LED1..LED4);
 *  - the push buttons SW2 and SW3 through the GPIO character device (/dev/gpiochipN, the
 *    chip labelled 20122000.gpio = MSS GPIO2), lines 30 and 31. In Microchip's Icicle
 *    reference design the fabric routes NOT(SW2) to GPIO2 input 30 and NOT(SW3) to input 31,
 *    so a pressed button reads 1.
 *
 * Usage: blinky [-p period_ms] [-n cycles] [-q]
 *   Runs LED1 -> LED4 in turn. SW2 reverses the direction, SW3 switches fast/slow.
 *   Ctrl-C (or -n cycles) stops it and turns the LEDs off.
 *
 * Build: riscv64-linux-gnu-gcc -static -Os -o blinky blinky.c   (tools/qemu/image builds it)
 */
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/gpio.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#define GPIO2_LABEL "20122000.gpio"
#define LINE_SW2 30
#define LINE_SW3 31

static volatile sig_atomic_t stop;

static void on_signal(int sig)
{
	(void)sig;
	stop = 1;
}

static int led_fd[4];

static int open_leds(void)
{
	char path[64];

	for (int i = 0; i < 4; i++) {
		snprintf(path, sizeof(path), "/sys/class/leds/led%d/brightness", i + 1);
		led_fd[i] = open(path, O_WRONLY);
		if (led_fd[i] < 0) {
			fprintf(stderr, "blinky: %s: %s\n", path, strerror(errno));
			return -1;
		}
	}
	return 0;
}

static void led_set(int i, int on)
{
	if (pwrite(led_fd[i], on ? "1" : "0", 1, 0) != 1)
		fprintf(stderr, "blinky: led%d: %s\n", i + 1, strerror(errno));
}

/* Find GPIO2 among /dev/gpiochip* by its label and request lines 30 and 31 as inputs. */
static int open_buttons(void)
{
	DIR *dir = opendir("/dev");
	struct dirent *de;
	int line_fd = -1;

	if (!dir)
		return -1;
	while (line_fd < 0 && (de = readdir(dir)) != NULL) {
		char path[300];
		struct gpiochip_info info;
		struct gpio_v2_line_request req;
		int chip;

		if (strncmp(de->d_name, "gpiochip", 8) != 0)
			continue;
		snprintf(path, sizeof(path), "/dev/%s", de->d_name);
		chip = open(path, O_RDONLY);
		if (chip < 0)
			continue;
		memset(&info, 0, sizeof(info));
		if (ioctl(chip, GPIO_GET_CHIPINFO_IOCTL, &info) == 0 &&
		    strcmp(info.label, GPIO2_LABEL) == 0) {
			memset(&req, 0, sizeof(req));
			req.offsets[0] = LINE_SW2;
			req.offsets[1] = LINE_SW3;
			req.num_lines = 2;
			req.config.flags = GPIO_V2_LINE_FLAG_INPUT;
			strcpy(req.consumer, "blinky");
			if (ioctl(chip, GPIO_V2_GET_LINE_IOCTL, &req) == 0)
				line_fd = req.fd;
			else
				fprintf(stderr, "blinky: %s lines %d,%d: %s\n", path, LINE_SW2, LINE_SW3,
					strerror(errno));
		}
		close(chip);
	}
	closedir(dir);
	return line_fd;
}

/* Bit 0 = SW2 pressed, bit 1 = SW3 pressed. */
static int read_buttons(int line_fd)
{
	struct gpio_v2_line_values v = { .mask = 3 };

	if (line_fd < 0 || ioctl(line_fd, GPIO_V2_LINE_GET_VALUES_IOCTL, &v) != 0)
		return 0;
	return (int)(v.bits & 3);
}

static void sleep_ms(int ms)
{
	struct timespec ts = { ms / 1000, (long)(ms % 1000) * 1000000L };

	nanosleep(&ts, NULL);
}

int main(int argc, char **argv)
{
	int period = 250, cycles = -1, quiet = 0, opt;

	while ((opt = getopt(argc, argv, "p:n:qh")) != -1) {
		switch (opt) {
		case 'p':
			period = atoi(optarg);
			break;
		case 'n':
			cycles = atoi(optarg);
			break;
		case 'q':
			quiet = 1;
			break;
		default:
			fprintf(stderr, "usage: blinky [-p period_ms] [-n cycles] [-q]\n"
					"  LED1..LED4 in turn; SW2 reverses, SW3 fast/slow; Ctrl-C stops.\n");
			return opt == 'h' ? 0 : 2;
		}
	}
	if (period < 20)
		period = 20;
	if (open_leds() != 0)
		return 1;
	int buttons = open_buttons();

	if (buttons < 0)
		fprintf(stderr, "blinky: no GPIO2 buttons (%s); LEDs only\n", GPIO2_LABEL);
	signal(SIGINT, on_signal);
	signal(SIGTERM, on_signal);
	if (!quiet)
		printf("blinky: LED1..LED4 every %d ms. SW2 reverses, SW3 fast/slow, Ctrl-C stops.\n",
		       period);
	fflush(stdout);

	int led = 0, dir = 1, fast = 0, last = read_buttons(buttons), done = 0;

	while (!stop && (cycles < 0 || done < cycles)) {
		for (int i = 0; i < 4; i++)
			led_set(i, i == led);
		if (!quiet) {
			printf("LED%d\n", led + 1);
			fflush(stdout);
		}
		/* Sleep one step in 10 ms slices, watching the buttons. */
		int step = fast ? period / 4 : period;

		for (int t = 0; t < step && !stop; t += 10) {
			int now = read_buttons(buttons);
			int pressed = now & ~last;

			if (pressed & 1) {
				dir = -dir;
				printf("SW2 pressed: direction %s\n", dir > 0 ? "LED1->LED4" : "LED4->LED1");
			}
			if (pressed & 2) {
				fast = !fast;
				printf("SW3 pressed: %s\n", fast ? "fast" : "slow");
			}
			if (pressed)
				fflush(stdout);
			last = now;
			sleep_ms(10);
		}
		led = (led + dir + 4) % 4;
		if (led == 0 && dir > 0)
			done++;
		else if (led == 3 && dir < 0)
			done++;
	}
	for (int i = 0; i < 4; i++)
		led_set(i, 0);
	if (!quiet)
		printf("blinky: done, LEDs off\n");
	return 0;
}
