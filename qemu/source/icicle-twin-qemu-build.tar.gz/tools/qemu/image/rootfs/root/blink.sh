#!/bin/sh
# blink.sh [rounds]: LED1..LED4 in turn through the Linux LED class (the shell version of blinky).
n=${1:-3}
i=0
while [ "$i" -lt "$n" ]; do
  for l in 1 2 3 4; do
    echo 1 > /sys/class/leds/led$l/brightness
    sleep 0.2
    echo 0 > /sys/class/leds/led$l/brightness
  done
  i=$((i + 1))
done
echo "blink.sh: $n rounds done"
