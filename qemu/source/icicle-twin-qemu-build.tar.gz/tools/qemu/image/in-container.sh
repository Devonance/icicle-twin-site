#!/usr/bin/env bash
# Runs inside ubuntu:24.04 (see build-image.sh). /spec = this folder (ro), /dl = downloads, /work = build, /out.
set -euo pipefail
LINUX_VERSION=${LINUX_VERSION:-6.18.57}
BUSYBOX_VERSION=${BUSYBOX_VERSION:-1.36.1}
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends gcc-riscv64-linux-gnu libc6-dev-riscv64-cross make gcc libc6-dev \
  flex bison bc xz-utils bzip2 curl ca-certificates cpio device-tree-compiler python3 perl openssl > /dev/null
J=$(nproc)
# busybox and blinky link the cross glibc statically (LGPL-2.1+): record exactly which one, so
# ../package-sources.sh can publish its source package (Built-Using names the glibc source version).
dpkg-query -W -f '${Package} ${Version} ${Built-Using}\n' libc6-dev-riscv64-cross gcc-riscv64-linux-gnu \
  > /out/toolchain.txt
cd /dl
# --- downloads (untrusted until the checksum matches) ---
if [ ! -f "linux-$LINUX_VERSION.tar.xz" ]; then
  curl -fLsO "https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-$LINUX_VERSION.tar.xz"
fi
curl -fLs -o sha256sums.asc https://cdn.kernel.org/pub/linux/kernel/v6.x/sha256sums.asc
grep " linux-$LINUX_VERSION.tar.xz\$" sha256sums.asc | sha256sum -c -
if [ ! -f "busybox-$BUSYBOX_VERSION.tar.bz2" ]; then
  curl -fLsO "https://busybox.net/downloads/busybox-$BUSYBOX_VERSION.tar.bz2"
fi
curl -fLs -o "busybox-$BUSYBOX_VERSION.tar.bz2.sha256" "https://busybox.net/downloads/busybox-$BUSYBOX_VERSION.tar.bz2.sha256"
sha256sum -c "busybox-$BUSYBOX_VERSION.tar.bz2.sha256"

if [ -n "${DTB_ONLY:-}" ]; then cd /work; else
# --- busybox (static) ---
cd /work
rm -rf "busybox-$BUSYBOX_VERSION" rootfs && tar xjf "/dl/busybox-$BUSYBOX_VERSION.tar.bz2"
cd "busybox-$BUSYBOX_VERSION"
make -s defconfig
sed -i -e 's/^# CONFIG_STATIC is not set/CONFIG_STATIC=y/' -e 's/^CONFIG_TC=y/# CONFIG_TC is not set/' .config
make -s CROSS_COMPILE=riscv64-linux-gnu- -j"$J" busybox
riscv64-linux-gnu-strip busybox
cp busybox /work/busybox.rv64
cd /work

# --- blinky, the trainee's test program (static, stripped) ---
riscv64-linux-gnu-gcc -static -Os -Wall -Wextra -o /work/blinky.rv64 /spec/blinky.c
riscv64-linux-gnu-strip /work/blinky.rv64
# --- oled-hello: "Hello" on the OLED W Click over spidev + PWM (D/C#) + GPIO (RES#) (issue #182) ---
riscv64-linux-gnu-gcc -static -Os -Wall -Wextra -o /work/oled-hello.rv64 /spec/oled-hello.c
riscv64-linux-gnu-strip /work/oled-hello.rv64
# root's password is "microchip", as on the twin's scripted Linux; a fixed salt keeps the image reproducible.
echo "root:$(openssl passwd -6 -salt IcicleTwinQEMU microchip):19000:0:99999:7:::" > /work/shadow

# --- initramfs list (gen_init_cpio format; no root or mknod needed) ---
{
  echo "dir /dev 755 0 0"
  echo "nod /dev/console 600 0 0 c 5 1"
  echo "nod /dev/null 666 0 0 c 1 3"
  for d in bin sbin usr usr/bin usr/sbin proc sys tmp root etc etc/init.d var var/run; do echo "dir /$d 755 0 0"; done
  echo "file /bin/busybox /work/busybox.rv64 755 0 0"
  # /init: the spike's PID 1 (rdinit=/init, icicle-spike.dtb); the app's dtb boots busybox init instead.
  echo "file /init /spec/init 755 0 0"
  echo "file /usr/bin/blinky /work/blinky.rv64 755 0 0"
  echo "file /root/blinky.c /spec/blinky.c 644 0 0"
  echo "file /usr/bin/oled-hello /work/oled-hello.rv64 755 0 0"
  echo "file /root/oled-hello.c /spec/oled-hello.c 644 0 0"
  echo "file /etc/shadow /work/shadow 600 0 0"
  (cd /spec/rootfs && find . -type f | sort) | while read -r f; do
    mode=644; case "$f" in ./etc/init.d/*|./usr/bin/*|*.sh) mode=755;; esac
    echo "file ${f#.} /spec/rootfs/${f#./} $mode 0 0"
  done
} > initramfs.list
# The applet list comes from the config (busybox.links), not from running the riscv binary.
(cd "busybox-$BUSYBOX_VERSION" && make -s busybox.links)
sed -e 's#^/##' "busybox-$BUSYBOX_VERSION/busybox.links" | while read -r p; do
  [ "$p" = bin/busybox ] && continue
  echo "slink /$p /bin/busybox 777 0 0"
done >> initramfs.list
echo "applets: $(grep -c slink initramfs.list)"

# --- Linux ---
rm -rf "linux-$LINUX_VERSION" && tar xJf "/dl/linux-$LINUX_VERSION.tar.xz"
cd "linux-$LINUX_VERSION"
KCONFIG_ALLCONFIG=/spec/linux.config make -s ARCH=riscv CROSS_COMPILE=riscv64-linux-gnu- allnoconfig
# Report fragment options that did not stick (missing deps or renamed symbols).
grep -E '^CONFIG_[A-Z0-9_]+=' /spec/linux.config | while IFS= read -r l; do
  k=${l%%=*}; v=${l#*=}
  if [ "$v" = n ]; then
    if grep -q "^$k=y" .config; then echo "kconfig: $k is still y"; fi
  else grep -qxF "$l" .config || echo "kconfig: $l did not stick ($(grep -E "^(# )?$k[= ]" .config || echo absent))"; fi
done
make -s ARCH=riscv CROSS_COMPILE=riscv64-linux-gnu- -j"$J" Image
cp arch/riscv/boot/Image /out/Image
cp .config /out/linux.config.full
cd /work
fi

# --- device tree ---
cpp -nostdinc -undef -x assembler-with-cpp -I "linux-$LINUX_VERSION/include" /spec/icicle-spike.dts \
  | dtc -I dts -O dtb -o /out/icicle-spike.dtb -
cpp -nostdinc -undef -x assembler-with-cpp -DSMP5 -I "linux-$LINUX_VERSION/include" /spec/icicle-spike.dts \
  | dtc -I dts -O dtb -o /out/icicle-spike-smp5.dtb -
cpp -nostdinc -undef -x assembler-with-cpp -I "linux-$LINUX_VERSION/include" /spec/icicle-twin.dts \
  | dtc -I dts -O dtb -o /out/icicle-twin.dtb -
cp "linux-$LINUX_VERSION/arch/riscv/boot/dts/microchip/mpfs.dtsi" /out/upstream-mpfs.dtsi
cp "linux-$LINUX_VERSION/arch/riscv/boot/dts/microchip/mpfs-icicle-kit.dts" /out/upstream-mpfs-icicle-kit.dts
ls -l /out
