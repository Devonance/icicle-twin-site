#!/usr/bin/env bash
# Build the spike's guest: Linux (LTS, from kernel.org) with a busybox initramfs built in, plus the
# device tree for QEMU's microchip-icicle-kit machine. Everything runs inside a throw-away
# ubuntu:24.04 container; downloads are checked against the publishers' sha256 lists.
#
#   WORK=~/qemu-spike bash tools/qemu/image/build-image.sh
#
# Output: $WORK/out/Image, $WORK/out/icicle-spike.dtb
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
WORK=${WORK:-$HOME/qemu-spike}
mkdir -p "$WORK/image-dl" "$WORK/image-build" "$WORK/out"
docker run --rm -e DTB_ONLY="${DTB_ONLY:-}" \
  -v "$HERE:/spec:ro" -v "$WORK/image-dl:/dl" -v "$WORK/image-build:/work" -v "$WORK/out:/out" \
  ubuntu:24.04 bash /spec/in-container.sh
ls -l "$WORK/out"
