// SPDX-License-Identifier: MIT
/*
 * oled-hello: draws "Hello" on the OLED W Click (SSD1306, 96 x 39) in mikroBUS J44/J8 from Linux
 * userspace, with the standard interfaces a program on the real Icicle Kit uses:
 *  - SPI through spidev: MSS SPI1 (spi-mpfs, 0x2010_9000), chip select 0 = MBUS_SPI_CS#;
 *    /dev/spidev1.0 (the device tree's alias spi1; the init script binds spidev to it);
 *  - D/C# through the PWM class: the Click's D/C# is the mikroBUS PWM pin, which the reference
 *    design drives from the fabric CorePWM (pwm-microchip-core, 0x4000_0000) channel 0. A duty cycle
 *    of 0 % holds it low (command), 100 % high (data);
 *  - RES# through the GPIO character device: MBUS_RST is MSS GPIO2 line 21 (chip 20122000.gpio).
 *
 * The bytes are the twin's own OLED demo (src/sim/peripherals/oled-ssd1306/firmware.ts): the
 * MI9639BO "Actual Application Example" init sequence, the 96 x 39 window (columns 32..127,
 * pages 0..4), the picture, display on, then a bar that slides along the bottom.
 *
 * Usage: oled-hello [-m text] [-n frames] [-l] [-s speed_hz] [-o]
 *   -m text    the middle line (default "FROM LINUX"), 16 characters at most
 *   -n frames  bar frames after the picture (default 24, 80 ms apart); -l: until Ctrl-C
 *   -s hz      SPI clock (default 10 MHz, the SSD1306's limit)
 *   -o         display off (AEh) and exit
 *
 * Build: riscv64-linux-gnu-gcc -static -Os -o oled-hello oled-hello.c   (tools/qemu/image builds it)
 */
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/gpio.h>
#include <linux/spi/spidev.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/utsname.h>
#include <time.h>
#include <unistd.h>

#define SPIDEV "/dev/spidev1.0"
#define GPIO2_LABEL "20122000.gpio"
#define LINE_MBUS_RST 21
#define PWM_DEVICE "40000000.pwm"
#define PWM_PERIOD_NS 1000000

#define W 96
#define H 39
#define COL0 32
#define PAGES 5

static volatile sig_atomic_t stop;
static int spi_fd = -1, rst_fd = -1;
static char pwm_dir[160];
static uint32_t spi_hz = 10000000;

static void on_signal(int sig)
{
	(void)sig;
	stop = 1;
}

static void sleep_us(long us)
{
	struct timespec ts = { us / 1000000, (us % 1000000) * 1000L };

	nanosleep(&ts, NULL);
}

static int write_file(const char *dir, const char *name, const char *text)
{
	char path[256];
	int fd, ok;

	snprintf(path, sizeof(path), "%s/%s", dir, name);
	fd = open(path, O_WRONLY);
	if (fd < 0)
		return -1;
	ok = write(fd, text, strlen(text)) == (ssize_t)strlen(text);
	close(fd);
	return ok ? 0 : -1;
}

/* The CorePWM chip among /sys/class/pwm/pwmchip*, channel 0 exported, 1 ms period, enabled. */
static int open_dc(void)
{
	DIR *dir = opendir("/sys/class/pwm");
	struct dirent *de;
	char chip[128] = "";

	if (!dir)
		return -1;
	while ((de = readdir(dir)) != NULL) {
		char link[256], target[256];
		ssize_t n;

		if (strncmp(de->d_name, "pwmchip", 7) != 0)
			continue;
		snprintf(link, sizeof(link), "/sys/class/pwm/%s/device", de->d_name);
		n = readlink(link, target, sizeof(target) - 1);
		if (n > 0) {
			target[n] = 0;
			if (strstr(target, PWM_DEVICE)) {
				snprintf(chip, sizeof(chip), "/sys/class/pwm/%s", de->d_name);
				break;
			}
		}
	}
	closedir(dir);
	if (!chip[0])
		return -1;
	snprintf(pwm_dir, sizeof(pwm_dir), "%s/pwm0", chip);
	if (access(pwm_dir, F_OK) != 0 && write_file(chip, "export", "0") != 0)
		return -1;
	char period[16];

	snprintf(period, sizeof(period), "%d", PWM_PERIOD_NS);
	/* the duty cycle may never exceed the period: 0 first (it may fail before a period is set) */
	(void)write_file(pwm_dir, "duty_cycle", "0");
	if (write_file(pwm_dir, "period", period) != 0)
		return -1;
	if (write_file(pwm_dir, "duty_cycle", "0") != 0)
		return -1;
	return write_file(pwm_dir, "enable", "1");
}

static int dc_level = -1;

/* D/C#: 0 = command, 1 = data (0 % or 100 % duty). */
static void set_dc(int level)
{
	char duty[16];

	if (level == dc_level)
		return;
	snprintf(duty, sizeof(duty), "%d", level ? PWM_PERIOD_NS : 0);
	if (write_file(pwm_dir, "duty_cycle", duty) != 0)
		fprintf(stderr, "oled-hello: %s/duty_cycle: %s\n", pwm_dir, strerror(errno));
	dc_level = level;
}

/* MBUS_RST (GPIO2 line 21) as an output, high. */
static int open_rst(void)
{
	DIR *dir = opendir("/dev");
	struct dirent *de;

	if (!dir)
		return -1;
	while (rst_fd < 0 && (de = readdir(dir)) != NULL) {
		char path[300];
		struct gpiochip_info info;
		struct gpio_v2_line_request req;
		int chip;

		if (strncmp(de->d_name, "gpiochip", 8) != 0)
			continue;
		snprintf(path, sizeof(path), "/dev/%s", de->d_name);
		chip = open(path, O_RDONLY);
		if (chip < 0)
			continue;
		memset(&info, 0, sizeof(info));
		if (ioctl(chip, GPIO_GET_CHIPINFO_IOCTL, &info) == 0 && strcmp(info.label, GPIO2_LABEL) == 0) {
			memset(&req, 0, sizeof(req));
			req.offsets[0] = LINE_MBUS_RST;
			req.num_lines = 1;
			req.config.flags = GPIO_V2_LINE_FLAG_OUTPUT;
			req.config.num_attrs = 1;
			req.config.attrs[0].attr.id = GPIO_V2_LINE_ATTR_ID_OUTPUT_VALUES;
			req.config.attrs[0].attr.values = 1;
			req.config.attrs[0].mask = 1;
			strcpy(req.consumer, "oled-hello");
			if (ioctl(chip, GPIO_V2_GET_LINE_IOCTL, &req) == 0)
				rst_fd = req.fd;
			else
				fprintf(stderr, "oled-hello: %s line %d: %s\n", path, LINE_MBUS_RST, strerror(errno));
		}
		close(chip);
	}
	closedir(dir);
	return rst_fd < 0 ? -1 : 0;
}

static void set_rst(int level)
{
	struct gpio_v2_line_values v = { .bits = (uint64_t)level, .mask = 1 };

	if (ioctl(rst_fd, GPIO_V2_LINE_SET_VALUES_IOCTL, &v) != 0)
		fprintf(stderr, "oled-hello: MBUS_RST: %s\n", strerror(errno));
}

static int open_spi(void)
{
	uint8_t mode = SPI_MODE_0, bits = 8;

	spi_fd = open(SPIDEV, O_RDWR);
	if (spi_fd < 0)
		return -1;
	if (ioctl(spi_fd, SPI_IOC_WR_MODE, &mode) != 0 || ioctl(spi_fd, SPI_IOC_WR_BITS_PER_WORD, &bits) != 0 ||
	    ioctl(spi_fd, SPI_IOC_WR_MAX_SPEED_HZ, &spi_hz) != 0)
		return -1;
	return 0;
}

/* One SPI transfer (CS# low for all of it) with D/C# at `dc`. */
static int send(int dc, const uint8_t *bytes, size_t n)
{
	struct spi_ioc_transfer t;

	set_dc(dc);
	memset(&t, 0, sizeof(t));
	t.tx_buf = (uintptr_t)bytes;
	t.len = (uint32_t)n;
	t.speed_hz = spi_hz;
	t.bits_per_word = 8;
	if (ioctl(spi_fd, SPI_IOC_MESSAGE(1), &t) != (int)n) {
		fprintf(stderr, "oled-hello: %s: %s\n", SPIDEV, strerror(errno));
		return -1;
	}
	return 0;
}

/* MI9639BO application example (VCC from the internal DC/DC), as firmware.ts INIT_SEQUENCE. */
static const uint8_t init_seq[] = {
	0xae, 0xd5, 0x80, 0xa8, 0x27, 0xd3, 0x00, 0x40, 0x8d, 0x14, 0xa1,
	0xc8, 0xda, 0x12, 0x81, 0xaf, 0xd9, 0x25, 0xdb, 0x20, 0xa4, 0xa6,
};
static const uint8_t window_all[] = { 0x20, 0x00, 0x21, COL0, 0x7f, 0x22, 0x00, PAGES - 1 };
static const uint8_t window_bar[] = { 0x21, COL0, 0x7f, 0x22, 0x04, 0x04 };
static const uint8_t display_on[] = { 0xaf };
static const uint8_t display_off[] = { 0xae };

/* 5 x 7 glyphs, rows top first, bit 4 = leftmost dot (the twin's own font, picture.ts). */
struct glyph {
	char c;
	uint8_t rows[7];
};
static const struct glyph font[] = {
	{ ' ', { 0, 0, 0, 0, 0, 0, 0 } },
	{ '.', { 0, 0, 0, 0, 0, 0x0c, 0x0c } },
	{ ':', { 0, 0x0c, 0x0c, 0, 0x0c, 0x0c, 0 } },
	{ '-', { 0, 0, 0, 0x1f, 0, 0, 0 } },
	{ '!', { 0x04, 0x04, 0x04, 0x04, 0x04, 0, 0x04 } },
	{ '0', { 0x0e, 0x11, 0x13, 0x15, 0x19, 0x11, 0x0e } },
	{ '1', { 0x04, 0x0c, 0x04, 0x04, 0x04, 0x04, 0x0e } },
	{ '2', { 0x0e, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1f } },
	{ '3', { 0x1f, 0x02, 0x04, 0x02, 0x01, 0x11, 0x0e } },
	{ '4', { 0x02, 0x06, 0x0a, 0x12, 0x1f, 0x02, 0x02 } },
	{ '5', { 0x1f, 0x10, 0x1e, 0x01, 0x01, 0x11, 0x0e } },
	{ '6', { 0x06, 0x08, 0x10, 0x1e, 0x11, 0x11, 0x0e } },
	{ '7', { 0x1f, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08 } },
	{ '8', { 0x0e, 0x11, 0x11, 0x0e, 0x11, 0x11, 0x0e } },
	{ '9', { 0x0e, 0x11, 0x11, 0x0f, 0x01, 0x02, 0x0c } },
	{ 'A', { 0x0e, 0x11, 0x11, 0x1f, 0x11, 0x11, 0x11 } },
	{ 'B', { 0x1e, 0x11, 0x11, 0x1e, 0x11, 0x11, 0x1e } },
	{ 'C', { 0x0e, 0x11, 0x10, 0x10, 0x10, 0x11, 0x0e } },
	{ 'D', { 0x1c, 0x12, 0x11, 0x11, 0x11, 0x12, 0x1c } },
	{ 'E', { 0x1f, 0x10, 0x10, 0x1e, 0x10, 0x10, 0x1f } },
	{ 'F', { 0x1f, 0x10, 0x10, 0x1e, 0x10, 0x10, 0x10 } },
	{ 'G', { 0x0e, 0x11, 0x10, 0x17, 0x11, 0x11, 0x0f } },
	{ 'H', { 0x11, 0x11, 0x11, 0x1f, 0x11, 0x11, 0x11 } },
	{ 'I', { 0x0e, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0e } },
	{ 'J', { 0x07, 0x02, 0x02, 0x02, 0x02, 0x12, 0x0c } },
	{ 'K', { 0x11, 0x12, 0x14, 0x18, 0x14, 0x12, 0x11 } },
	{ 'L', { 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1f } },
	{ 'M', { 0x11, 0x1b, 0x15, 0x15, 0x11, 0x11, 0x11 } },
	{ 'N', { 0x11, 0x19, 0x15, 0x13, 0x11, 0x11, 0x11 } },
	{ 'O', { 0x0e, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0e } },
	{ 'P', { 0x1e, 0x11, 0x11, 0x1e, 0x10, 0x10, 0x10 } },
	{ 'Q', { 0x0e, 0x11, 0x11, 0x11, 0x15, 0x12, 0x0d } },
	{ 'R', { 0x1e, 0x11, 0x11, 0x1e, 0x14, 0x12, 0x11 } },
	{ 'S', { 0x0f, 0x10, 0x10, 0x0e, 0x01, 0x01, 0x1e } },
	{ 'T', { 0x1f, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04 } },
	{ 'U', { 0x11, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0e } },
	{ 'V', { 0x11, 0x11, 0x11, 0x11, 0x11, 0x0a, 0x04 } },
	{ 'W', { 0x11, 0x11, 0x11, 0x15, 0x15, 0x15, 0x0a } },
	{ 'X', { 0x11, 0x11, 0x0a, 0x04, 0x0a, 0x11, 0x11 } },
	{ 'Y', { 0x11, 0x11, 0x0a, 0x04, 0x04, 0x04, 0x04 } },
	{ 'Z', { 0x1f, 0x01, 0x02, 0x04, 0x08, 0x10, 0x1f } },
	{ 'e', { 0, 0, 0x0e, 0x11, 0x1f, 0x10, 0x0e } },
	{ 'l', { 0x0c, 0x04, 0x04, 0x04, 0x04, 0x04, 0x0e } },
	{ 'o', { 0, 0, 0x0e, 0x11, 0x11, 0x11, 0x0e } },
};

static uint8_t px[H][W];

static const uint8_t *glyph(char c)
{
	for (size_t i = 0; i < sizeof(font) / sizeof(font[0]); i++)
		if (font[i].c == c)
			return font[i].rows;
	if (c >= 'a' && c <= 'z')
		return glyph((char)(c - 'a' + 'A'));
	return font[0].rows;
}

static void fill(int x0, int y0, int w, int h)
{
	for (int y = y0; y < y0 + h; y++)
		for (int x = x0; x < x0 + w; x++)
			if (x >= 0 && y >= 0 && x < W && y < H)
				px[y][x] = 1;
}

static void text_centred(const char *s, int y0, int scale)
{
	int n = (int)strlen(s);
	int x = (W - (n * 6 - 1) * scale) / 2;

	for (; *s; s++, x += 6 * scale) {
		const uint8_t *g = glyph(*s);

		for (int r = 0; r < 7; r++)
			for (int c = 0; c < 5; c++)
				if (g[r] & (0x10 >> c))
					fill(x + c * scale, y0 + r * scale, scale, scale);
	}
}

/* The picture for bar frame `frame` (picture.ts helloPicture, with its own lines). */
static void picture(int frame, const char *middle, const char *bottom)
{
	const int bar_w = 18, bar_y = 36, step = 6, span = W + bar_w;

	memset(px, 0, sizeof(px));
	text_centred("Hello", 1, 2);
	text_centred(middle, 18, 1);
	text_centred(bottom, 27, 1);
	fill((frame * step) % span - bar_w, bar_y, bar_w, 2);
	fill(0, bar_y + 2, W, 1);
}

/* GDDRAM bytes of pages from..to in horizontal-addressing order; image row y is RAM row y + 1. */
static size_t window_bytes(uint8_t *out, int from, int to)
{
	size_t n = 0;

	for (int page = from; page <= to; page++)
		for (int x = 0; x < W; x++) {
			uint8_t b = 0;

			for (int bit = 0; bit < 8; bit++) {
				int y = page * 8 + bit - 1;

				if (y >= 0 && y < H && px[y][x])
					b |= (uint8_t)(1 << bit);
			}
			out[n++] = b;
		}
	return n;
}

int main(int argc, char **argv)
{
	const char *middle = "FROM LINUX";
	char bottom[17];
	int frames = 24, loop = 0, off = 0, opt;
	struct utsname u;
	uint8_t buf[PAGES * W];

	while ((opt = getopt(argc, argv, "m:n:ls:oh")) != -1) {
		switch (opt) {
		case 'm':
			middle = optarg;
			break;
		case 'n':
			frames = atoi(optarg);
			break;
		case 'l':
			loop = 1;
			break;
		case 's':
			spi_hz = (uint32_t)strtoul(optarg, NULL, 0);
			break;
		case 'o':
			off = 1;
			break;
		default:
			fprintf(stderr, "usage: oled-hello [-m text] [-n frames] [-l] [-s speed_hz] [-o]\n"
					"  \"Hello\" on the OLED W Click in mikroBUS (SPI1 + D/C# on PWM + RES# on GPIO2 21)\n");
			return opt == 'h' ? 0 : 2;
		}
	}
	if (strlen(middle) > 16) {
		fprintf(stderr, "oled-hello: -m: 16 characters at most\n");
		return 2;
	}
	if (open_spi() != 0) {
		fprintf(stderr, "oled-hello: %s: %s (is spidev bound to spi1.0?)\n", SPIDEV, strerror(errno));
		return 1;
	}
	if (open_dc() != 0) {
		fprintf(stderr, "oled-hello: no CorePWM channel 0 (%s) for D/C#: %s\n", PWM_DEVICE, strerror(errno));
		return 1;
	}
	if (open_rst() != 0) {
		fprintf(stderr, "oled-hello: no MBUS_RST (%s line %d)\n", GPIO2_LABEL, LINE_MBUS_RST);
		return 1;
	}
	if (off) {
		send(0, display_off, sizeof(display_off));
		printf("oled-hello: display off\n");
		return 0;
	}
	signal(SIGINT, on_signal);
	signal(SIGTERM, on_signal);
	uname(&u);
	snprintf(bottom, sizeof(bottom), "LINUX %.10s", u.release);
	printf("oled-hello: %s at %u kHz, D/C# = PWM (%s), RES# = MBUS_RST (GPIO2 %d)\n", SPIDEV,
	       spi_hz / 1000, pwm_dir, LINE_MBUS_RST);
	fflush(stdout);

	/* RES# low for 10 us (the SSD1306 needs 3 us), then high and 10 us before the first command. */
	set_rst(0);
	sleep_us(10);
	set_rst(1);
	sleep_us(10);
	if (send(0, init_seq, sizeof(init_seq)) || send(0, window_all, sizeof(window_all)))
		return 1;
	picture(0, middle, bottom);
	if (send(1, buf, window_bytes(buf, 0, PAGES - 1)) || send(0, display_on, sizeof(display_on)))
		return 1;
	printf("oled-hello: \"Hello\" is on the OLED W Click.\n");
	fflush(stdout);
	for (int f = 1; !stop && (loop || f <= frames); f++) {
		sleep_us(80000);
		picture(f, middle, bottom);
		if (send(0, window_bar, sizeof(window_bar)) || send(1, buf, window_bytes(buf, 4, 4)))
			return 1;
	}
	printf("oled-hello: done (%s)\n", stop ? "stopped" : "picture stays on");
	return 0;
}
