#!/usr/bin/env bash
# Boot the spike guest on the native QEMU build (baseline), type a few commands, print the log with
# host timestamps. Needs build-qemu-native.sh and image/build-image.sh output.
#
#   WORK=~/qemu-spike bash tools/qemu/run-native.sh [extra qemu args]
set -euo pipefail
WORK=${WORK:-$HOME/qemu-spike}
Q=$WORK/native/build/qemu-system-riscv64
O=$WORK/out
start=$(date +%s.%N)
{
  sleep "${WAIT:-6}"
  echo 'cat /proc/cpuinfo; ls /sys/class/leds'
  echo 'echo 1 > /sys/class/leds/led1/brightness; devmem 0x20122088 32'
  echo 'devmem 0x201220a4 32 0x000f0000; devmem 0x20122088 32'
  echo "time sh -c 'i=0; while [ \$i -lt 5000 ]; do i=\$((i+1)); done'"
  sleep "${TAIL:-4}"
} | timeout "${TIMEOUT:-20}" "$Q" -M microchip-icicle-kit -smp 2 -m 256M -display none -monitor none \
    -serial null -serial stdio -nic none -L "$O" \
    -kernel "$O/Image" -dtb "$O/icicle-spike.dtb" "$@" 2>&1 |
  while IFS= read -r line; do printf '[%6.2f] %s\n' "$(echo "$(date +%s.%N) - $start" | bc)" "$line"; done || true
