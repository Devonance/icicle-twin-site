#!/usr/bin/env bash
# Package the corresponding source of everything in public/qemu/bin (QEMU, OpenSBI, Linux, BusyBox, the
# static glibc and the libraries linked into the WebAssembly build) with our patches and build scripts,
# into public/qemu/source/ (git-ignored), which tools/deploy/publish-local.sh publishes next to the
# binaries. What is in it and why: tools/qemu/SOURCES.md.
#
#   WORK=~/qemu-spike bash tools/qemu/package-sources.sh
#
# Needs Linux with curl, sha256sum, tar, xz, split. Downloads go to $WORK/sources (cached). Every
# download is checked against a pinned sha256 below, or against the publisher's signed list (kernel.org,
# busybox.net). Files over 95 MB are split (GitHub refuses files over 100 MB); README.txt says how to
# join them.
set -euo pipefail
WORK=${WORK:-$HOME/qemu-spike}
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/../.." && pwd)
DL=$WORK/sources
DEST=$ROOT/public/qemu/source
mkdir -p "$DL"

# --- versions: keep in step with build-qemu-wasm.sh, Dockerfile.toolchain, image/in-container.sh ---
QEMU_WASM_COMMIT=$(sed -n 's/^QEMU_WASM_COMMIT=\([0-9a-f]*\).*/\1/p' "$HERE/build-qemu-wasm.sh")
DTC_COMMIT=b6910bec11614980a21e46fbccc35934b671bd81          # qemu-wasm subprojects/dtc.wrap
OPENSBI_TAG=v1.3.1                                           # QEMU 8.2 pc-bios fw_dynamic banner
LINUX_VERSION=$(sed -n 's/^LINUX_VERSION=\${LINUX_VERSION:-\(.*\)}$/\1/p' "$HERE/image/in-container.sh")
BUSYBOX_VERSION=$(sed -n 's/^BUSYBOX_VERSION=\${BUSYBOX_VERSION:-\(.*\)}$/\1/p' "$HERE/image/in-container.sh")
GLIB_VERSION=2.75.0
ZLIB_VERSION=1.3.1
PIXMAN_VERSION=0.42.2
FFI_COMMIT=adbcf2b247696dde2667ab552cb93e0c79455c84
EMSDK_VERSION=3.1.50
# The glibc the cross toolchain was built from (image/in-container.sh writes toolchain.txt).
GLIBC_UBUNTU=$(grep -o 'glibc (= [^)]*)' "$WORK/out/toolchain.txt" 2>/dev/null | sed 's/glibc (= \(.*\))/\1/' || true)
GLIBC_UBUNTU=${GLIBC_UBUNTU:-2.39-0ubuntu8}
GLIBC_UPSTREAM=${GLIBC_UBUNTU%%-*}

fetch() { # fetch <file> <url> [sha256]
  local f=$1 url=$2 sum=${3:-}
  if [ ! -s "$DL/$f" ]; then
    echo "download $f"
    curl -fL --retry 3 -s -o "$DL/$f.part" "$url"
    mv "$DL/$f.part" "$DL/$f"
  fi
  if [ -n "$sum" ]; then echo "$sum  $DL/$f" | sha256sum -c --quiet -; fi
}

# The sha256 a .dsc lists for one of its files.
dsc_sum() { sed -n '/^Checksums-Sha256:/,/^[^ ]/p' "$DL/glibc_$GLIBC_UBUNTU.dsc" | awk -v f="$1" '$3 == f { print $1 }'; }

# Archives from GitHub/GitLab (codeload) are pinned too; if a forge ever regenerates one, compare the
# unpacked tree with the commit before updating its sum.
# QEMU (ktock/qemu-wasm at the pinned commit; QEMU 8.2.0 base) and the dtc subproject it builds libfdt from.
fetch "qemu-wasm-$QEMU_WASM_COMMIT.tar.gz" "https://codeload.github.com/ktock/qemu-wasm/tar.gz/$QEMU_WASM_COMMIT" \
  e78094503df31cd373f5609247c1a0c9bf771b75f68398c679e361bd3b4808c2
fetch "dtc-$DTC_COMMIT.tar.gz" "https://gitlab.com/qemu-project/dtc/-/archive/$DTC_COMMIT/dtc-$DTC_COMMIT.tar.gz" \
  e115f987eec23a1ba25150a46ced1675de3716072d3b4905afb3a9cda0f007c7
# OpenSBI (the fw_dynamic.bin is QEMU's prebuilt pc-bios copy of this release).
fetch "opensbi-$OPENSBI_TAG.tar.gz" "https://codeload.github.com/riscv-software-src/opensbi/tar.gz/refs/tags/$OPENSBI_TAG" \
  ee5be2c582f9a837e9db88368220758e014dd694b566bb6c8efe1e50cfad0004
# Linux and BusyBox: checked against the publishers' lists, as the image build does.
fetch "linux-$LINUX_VERSION.tar.xz" "https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-$LINUX_VERSION.tar.xz"
fetch sha256sums.asc https://cdn.kernel.org/pub/linux/kernel/v6.x/sha256sums.asc
(cd "$DL" && grep " linux-$LINUX_VERSION.tar.xz\$" sha256sums.asc | sha256sum -c --quiet -)
fetch "busybox-$BUSYBOX_VERSION.tar.bz2" "https://busybox.net/downloads/busybox-$BUSYBOX_VERSION.tar.bz2"
fetch "busybox-$BUSYBOX_VERSION.tar.bz2.sha256" "https://busybox.net/downloads/busybox-$BUSYBOX_VERSION.tar.bz2.sha256"
(cd "$DL" && sha256sum -c --quiet "busybox-$BUSYBOX_VERSION.tar.bz2.sha256")
# glibc as Ubuntu built the riscv64 cross libc (static in busybox and blinky): the source package.
LP=https://launchpad.net/ubuntu/+archive/primary/+sourcefiles/glibc/$GLIBC_UBUNTU
fetch "glibc_$GLIBC_UBUNTU.dsc" "$LP/glibc_$GLIBC_UBUNTU.dsc"  # the .dsc lists the sha256 of the other two
fetch "glibc_$GLIBC_UPSTREAM.orig.tar.xz" "$LP/glibc_$GLIBC_UPSTREAM.orig.tar.xz" \
  "$(dsc_sum "glibc_$GLIBC_UPSTREAM.orig.tar.xz")"
fetch "glibc_$GLIBC_UBUNTU.debian.tar.xz" "$LP/glibc_$GLIBC_UBUNTU.debian.tar.xz" \
  "$(dsc_sum "glibc_$GLIBC_UBUNTU.debian.tar.xz")"
# Libraries linked into qemu-system-riscv64.wasm (Dockerfile.toolchain).
fetch "glib-$GLIB_VERSION.tar.xz" "https://download.gnome.org/sources/glib/${GLIB_VERSION%.*}/glib-$GLIB_VERSION.tar.xz" \
  6dde8e55cc4a2c83d96797120b08bcffb5f645b2e212164ae22d63c40e0e6360
fetch "zlib-$ZLIB_VERSION.tar.xz" "https://github.com/madler/zlib/releases/download/v$ZLIB_VERSION/zlib-$ZLIB_VERSION.tar.xz" \
  38ef96b8dfe510d42707d9c781877914792541133e1870841463bfa73f883e32
fetch "pixman-$PIXMAN_VERSION.tar.gz" "https://www.cairographics.org/releases/pixman-$PIXMAN_VERSION.tar.gz" \
  ea1480efada2fd948bc75366f7c349e1c96d3297d09a3fe62626e38e234a625e
fetch "libffi-$FFI_COMMIT.tar.gz" "https://codeload.github.com/libffi/libffi/tar.gz/$FFI_COMMIT" \
  1f5e7a1231b6cb9f747189c48b15bbf17afdda6e2f9684b386fd19e9bbe78649
fetch "emscripten-$EMSDK_VERSION.tar.gz" "https://codeload.github.com/emscripten-core/emscripten/tar.gz/refs/tags/$EMSDK_VERSION" \
  6cebaac67c957441152c3075a901c91c41460c2d2df3d4ba45e6309fbc3b1e18
# The finale's Freedoom pack (doom/): doomgeneric (GPL-2.0, static with the same glibc) and Freedoom
# (BSD-3-Clause; not required, published for completeness), the versions doom/in-container.sh pins.
DG_COMMIT=$(sed -n 's/^DG_COMMIT=\([0-9a-f]*\).*/\1/p' "$HERE/doom/in-container.sh")
DG_SHA256=$(sed -n 's/^DG_SHA256=\([0-9a-f]*\).*/\1/p' "$HERE/doom/in-container.sh")
FD_VERSION=$(sed -n 's/^FD_VERSION=\(.*\)$/\1/p' "$HERE/doom/in-container.sh")
FD_SHA256=$(sed -n 's/^FD_SHA256=\([0-9a-f]*\).*/\1/p' "$HERE/doom/in-container.sh")
fetch "doomgeneric-$DG_COMMIT.tar.gz" "https://codeload.github.com/ozkl/doomgeneric/tar.gz/$DG_COMMIT" "$DG_SHA256"
fetch "freedoom-$FD_VERSION.zip" \
  "https://github.com/freedoom/freedoom/releases/download/v$FD_VERSION/freedoom-$FD_VERSION.zip" "$FD_SHA256"

# Our part: patches, build scripts, kernel config, device tree, rootfs, blinky, SOURCES.md.
rm -rf "$DEST"
mkdir -p "$DEST"
tar -C "$ROOT" --sort=name --owner=0 --group=0 --numeric-owner --mtime='2026-01-01 00:00Z' \
  -czf "$DEST/icicle-twin-qemu-build.tar.gz" tools/qemu
[ -f "$WORK/out/linux.config.full" ] && cp "$WORK/out/linux.config.full" "$DEST/linux-$LINUX_VERSION.config"
[ -f "$WORK/out/toolchain.txt" ] && cp "$WORK/out/toolchain.txt" "$DEST/toolchain.txt"
[ -f "$WORK/out/doom-toolchain.txt" ] && cp "$WORK/out/doom-toolchain.txt" "$DEST/doom-toolchain.txt"
cp "$HERE/SOURCES.md" "$DEST/SOURCES.md"

for f in "$DL"/*; do
  case "$(basename "$f")" in *.part|sha256sums.asc|*.sha256) continue;; esac
  size=$(stat -c %s "$f")
  if [ "$size" -gt 95000000 ]; then
    split -b 90M -d -a 2 "$f" "$DEST/$(basename "$f").part"
  else
    cp "$f" "$DEST/"
  fi
done

cat > "$DEST/README.txt" <<EOF
Corresponding source for the Icicle Twin's "Real CPU (QEMU)" mode (the files in ../bin/).
What each file is, its licence and how it was built: SOURCES.md. Rebuild: icicle-twin-qemu-build.tar.gz
(tools/qemu/README.md inside it).

Files split because the site cannot hold files over 100 MB, joined like this:
  cat linux-$LINUX_VERSION.tar.xz.part* > linux-$LINUX_VERSION.tar.xz
Then check everything:  sha256sum -c SHA256SUMS
EOF
(cd "$DEST" && sha256sum -- * | grep -v ' SHA256SUMS$' > SHA256SUMS)
# The original (unsplit) files' sums too, for after joining.
for f in "$DL"/*; do
  case "$(basename "$f")" in *.part|sha256sums.asc|*.sha256) continue;; esac
  [ "$(stat -c %s "$f")" -gt 95000000 ] && (cd "$DL" && sha256sum "$(basename "$f")") >> "$DEST/SHA256SUMS"
done

# A plain index page, so the card's "source code" link lands somewhere readable.
{
  echo '<!doctype html><meta charset="utf-8"><title>Icicle Twin QEMU sources</title>'
  echo '<style>body{font:14px/1.5 system-ui,sans-serif;max-width:820px;margin:24px auto;padding:0 16px}td{padding:2px 12px 2px 0}</style>'
  echo '<h1>Corresponding source: Real CPU (QEMU) mode</h1>'
  echo '<p>QEMU, Linux, BusyBox and doomgeneric are GPL-2.0; glibc and glib are LGPL-2.1+; Freedoom is BSD-3-Clause; the rest is permissive.'
  echo 'Details and build steps: <a href="SOURCES.md">SOURCES.md</a>, <a href="README.txt">README.txt</a>.</p><table>'
  (cd "$DEST" && for f in *; do
    [ "$f" = index.html ] && continue
    printf '<tr><td><a href="%s">%s</a></td><td>%s</td></tr>\n' "$f" "$f" "$(numfmt --to=si --suffix=B "$(stat -c %s "$f")")"
  done)
  echo '</table>'
} > "$DEST/index.html"

du -sh "$DEST"
ls -l "$DEST"
