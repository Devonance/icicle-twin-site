// Measure the app's "Real CPU (QEMU)" mode like a first visit: a fresh browser context (no service worker,
// empty HTTP cache), headed Chromium on the real GPU (headless software rendering slows QEMU several
// times). Times are ms from the Start click; the board is powered by commands (not the narrated P,
// which plays its steps in slow motion).
//
//   npm run build && npx vite preview --port 47613   (or BASE_PATH=/icicle-twin-site/ for both)
//   node tools/qemu/measure-app.cjs http://127.0.0.1:47613/ [runs]
const path = require('node:path');
const { chromium } = require(path.resolve(__dirname, '../../node_modules/playwright'));

const url = process.argv[2] ?? 'http://127.0.0.1:47613/';
const runs = Number(process.argv[3] ?? 3);

async function run(browser, n) {
  const ctx = await browser.newContext({ viewport: { width: 1600, height: 950 } });
  const page = await ctx.newPage();
  const nav = Date.now();
  await page.goto(url);
  await page.waitForFunction(() => document.documentElement.dataset.twinReady === 'true', null, { timeout: 90000 });
  const appReady = Date.now() - nav;
  await page.click('.tw-pill-engine');
  const click = Date.now();
  await page.click('.tw-qemu-start');
  await page.waitForFunction(() => crossOriginIsolated && document.documentElement.dataset.twinReady === 'true', null, {
    timeout: 90000,
  });
  const isolated = Date.now() - click;
  await page.waitForFunction(() => window.__qemu?.state === 'held' && window.__qemu.timings.downloaded !== undefined, null, {
    timeout: 120000,
  });
  const downloaded = Date.now() - click;
  const power = Date.now();
  await page.evaluate(() => {
    const h = window.__twin.host;
    h.send({ type: 'power', connected: true });
    h.send({ type: 'switch', id: 'SW6', position: 'on' });
  });
  await page.waitForFunction(() => window.__qemu.state === 'running', null, { timeout: 120000, polling: 20 });
  const running = Date.now() - power;
  await page.waitForFunction(() => window.__qemu.output[1].includes('login:'), null, { timeout: 120000, polling: 20 });
  const login = Date.now() - power;
  // A power cycle: SW6 off, on again; QEMU is reset through its control window.
  await page.evaluate(() => window.__twin.host.send({ type: 'switch', id: 'SW6', position: 'off' }));
  await page.waitForFunction(() => window.__qemu.state === 'held', null, { timeout: 60000, polling: 20 });
  const again = Date.now();
  await page.evaluate(() => window.__twin.host.send({ type: 'switch', id: 'SW6', position: 'on' }));
  await page.waitForFunction(() => window.__qemu.state === 'running', null, { timeout: 60000, polling: 20 });
  await page.waitForFunction(() => window.__qemu.output[1].includes('login:'), null, { timeout: 120000, polling: 20 });
  const relogin = Date.now() - again;
  const result = {
    run: n,
    appReadyMs: appReady,
    isolationReloadMs: isolated,
    downloadedMs: downloaded,
    downloadedBytes: await page.evaluate(() => window.__qemu.bytes),
    powerToQemuRunningMs: running,
    powerToLoginMs: login,
    powerCycleToLoginMs: relogin,
    timings: await page.evaluate(() => window.__qemu.timings),
  };
  await ctx.close();
  return result;
}

(async () => {
  const browser = await chromium.launch({ headless: false, args: ['--ignore-gpu-blocklist', '--enable-gpu'] });
  for (let i = 1; i <= runs; i++) console.log(JSON.stringify(await run(browser, i)));
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
