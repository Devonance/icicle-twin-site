# tools/qemu: QEMU in the browser

Builds what the app's "Real CPU (QEMU)" mode loads (`public/qemu/bin/`, see `docs/QEMU_MODE.md`) and what
the standalone spike page loads (`public/qemu-spike/bin/`, `docs/QEMU_SPIKE.md`): `qemu-system-riscv64`
compiled to WebAssembly, and a small Linux + busybox guest for QEMU's `microchip-icicle-kit` machine.

The binaries are not in git (18.2 MB raw, 6.8 MB gzip, plus the finale's Freedoom pack 19.4 MB raw,
6.6 MB gzip, fetched only by the finale), nor is their source bundle (268 MB). Produce them like this.

## Needs

Linux with Docker (WSL2 Ubuntu 24.04 + Docker Desktop was used), `git`, `brotli`, `curl`. About 5 GB of
disk under `$WORK`, 10-15 minutes on 32 threads.

## Steps (run from the repository root, in Linux/WSL)

```sh
export WORK=~/qemu-spike                 # keep it on the Linux filesystem, not /mnt/c
bash tools/qemu/build-qemu-wasm.sh       # QEMU -> $WORK/out/qemu-system-riscv64.{js,wasm,worker.js}
bash tools/qemu/image/build-image.sh     # Linux + busybox + blinky + dtbs -> $WORK/out/
bash tools/qemu/doom/build-doom.sh       # the finale's Freedoom pack -> $WORK/out/freedoom-pack.cpio
bash tools/qemu/stage.sh                 # -> public/qemu/bin/ + manifest.json; prints raw/gzip/brotli sizes
bash tools/qemu/package-sources.sh       # -> public/qemu/source/: the GPL/LGPL corresponding source
```

`stage.sh spike` stages the spike page's set into `public/qemu-spike/bin/` instead.

Then, on Windows or Linux: `npm run build && npx vite preview --port 47613`, open the app and use the
`Real CPU` pill in the top bar. `tools/deploy/publish-local.sh` publishes `public/qemu/{bin,source}` with the
site (and refuses binaries without sources).

Rebuilding after a patch change: `build-qemu-wasm.sh` records applied patches in
`$WORK/src/qemu-wasm/.icicle-twin-patches`; a patch edited since it was applied needs `CLEAN_SRC=1` (fresh
clone) and, for a new configure, `CLEAN=1` (fresh build container). The build container keeps the build
directory; a second `$WORK` tree beside the first gets its own with `CONTAINER=<name>` (and `IMAGE=` for
a toolchain image under another name).

Optional native baseline (same patched tree, x86-64): `bash tools/qemu/build-qemu-native.sh`, then
`bash tools/qemu/run-native.sh` boots the spike guest in a terminal and types a few commands.

## Measuring and screenshots

- `node tools/qemu/measure-app.cjs <url> [runs]`: the app's QEMU mode like a first visit (fresh context,
  headed Chromium on the real GPU): isolation reload, download, power-on to login prompt, power cycle.
- `node tools/qemu/shoot-app.cjs <url> docs/shots/qemu-1`: the card, blinky on the photoreal and x-ray board.
- `node tools/qemu/shoot.cjs <url> <dir|-> [runs]`: the spike page's timings and shots.
- `node tools/qemu/finale-app.cjs <url> [runs] [shots-dir]`: the finale in Real CPU mode (issue #164) like a
  first visit: power-on to lspci and to the first Freedoom frame, frame rates; shots of the monitor
  (photoreal, x-ray) and frames as QEMU scanned them out. `tests/e2e/finale-qemu.spec.ts` runs the same
  in `npm run test:e2e` when the Freedoom pack is staged.
- `tests/e2e/qemu-mode.spec.ts` runs in `npm run test:e2e` when `public/qemu/bin` is staged (skipped otherwise).
- `tests/e2e/qemu-bridges.spec.ts` (issue #182): `oled-hello` on the OLED W Click (SPI1; the analyser decodes
  it; both views), `i2cget -y 0 0x10 0xfd` and `pac-power` from the PAC1934 (I2C1). Skipped without the
  binaries or with a build before patch 0006. `SHOTS=1` writes `docs/shots/qemu-2/`.

Spike page options: `?smp=5` (E51 + all four U54s), `?thread=multi` (multi-threaded TCG), `?append=...`.

## Files

| File | What |
|---|---|
| `build-qemu-wasm.sh` | Fetches ktock/qemu-wasm at a pinned commit, applies `patches/`, builds in the `buildqemu` container |
| `Dockerfile.toolchain` | The Emscripten 3.1.50 + glib/zlib/libffi/pixman toolchain image, from qemu-wasm's Dockerfile (one URL fixed) |
| `patches/0001-*.patch` | `microchip-icicle-kit`: small RAM for direct kernel boot; GPIO2 register model + shared-memory window; console ring for MMUART1 (spike) |
| `patches/0002-*.patch` | Emscripten only: QEMU's main loop sleeps in its worker instead of busy-polling the page's main thread (spike) |
| `patches/0003-*.patch` | Console rings for MMUART0-4, GPIO2 input pads, a control window (hold / reset and run) for the twin's power |
| `patches/0004-*.patch` | Emscripten only: event notifiers as shared-memory flags + futex (no proxied syscalls); JIT counter |
| `patches/0006-*.patch` | mikroBUS and I2C1 (issue #182): MSS SPI1 (spi-mpfs registers), the fabric CorePWM (channel 0 = mikroBUS PWM, the OLED's D/C#) and MBUS_RST (GPIO2 21) into one ring the page drains, batched per transfer; MSS I2C1 (CoreI2C master) posting each bus step that needs a device's answer and raising SI once the page has answered from the twin |
| `patches/0005-*.patch` | PCIe: QEMU's generic ECAM host at the PolarFire root port's addresses (INTx ORed onto PLIC 119); the display card (bochs-display) plugged or pulled at power-on through the control window (version 2); the card's scan-out window (mode + a frame counter from the VRAM dirty log) |
| `doom/build-doom.sh`, `doom/in-container.sh` | The finale's Freedoom pack: doomgeneric for riscv64 Linux (static), Freedoom 0.13.0 trimmed, as one initrd (cpio) |
| `doom/doomgeneric_icicle.c` | doomgeneric's platform layer: /dev/fb0 with pwrite (no deferred-I/O delay), modeset via FBIOPUT_VSCREENINFO, no input, prints its frame rate (GPL-2.0, from `doomgeneric_linuxvt.c`) |
| `doom/mkpack.py`, `doom/S90freedoom` | IWAD trim (the demos' four maps, no sound effects) and the cpio writer; the start script (lspci, then Doom) |
| `finale-app.cjs` | Finale measurements and shots (above) |
| `image/build-image.sh`, `image/in-container.sh` | Linux 6.18.57 + busybox 1.36.1 (sha256-checked) + blinky, built in `ubuntu:24.04`; records the cross toolchain in `toolchain.txt` |
| `image/linux.config` | Kernel config fragment (allnoconfig + this) |
| `image/icicle-twin.dts` | The app's device tree: five harts, 256 MiB, MMUART1-4, GPIO2 with line names, LEDs, PCIe, SPI1 (with the OLED), CorePWM, I2C1 |
| `image/icicle-spike.dts`, `image/init` | The spike page's device tree and PID 1 (still in the image) |
| `image/rootfs/` | The app guest's `/etc` (busybox init, getty on ttyS1, root / microchip, motd) and `/root/blink.sh` |
| `image/blinky.c` | The trainee's test program: LED class + GPIO character device (MIT) |
| `image/oled-hello.c` | "Hello" on the OLED W Click from userspace: spidev (`/dev/spidev1.0`), D/C# through the PWM class (CorePWM channel 0), RES# through the GPIO character device (GPIO2 line 21) (MIT) |
| `image/rootfs/etc/init.d/S20mikrobus`, `image/rootfs/usr/bin/pac-power` | Binds spidev to spi1.0 (the device tree names the SSD1306 there); the PAC1934's four rails with i2c-tools (REFRESH, then one block read of VBUS1..4 and VSENSE1..4) |
| `stage.sh` | Copies the outputs to `public/qemu/bin/` (+ `manifest.json`) or `public/qemu-spike/bin/`, prints sizes |
| `package-sources.sh`, `SOURCES.md` | The corresponding-source bundle and what is in it |
| `measure-app.cjs`, `shoot-app.cjs` | App measurements and screenshots (above) |
| `build-qemu-native.sh`, `run-native.sh`, `shoot.cjs` | Native baseline; spike page measurements |
