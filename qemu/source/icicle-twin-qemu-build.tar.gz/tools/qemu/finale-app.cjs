// The finale in Real CPU mode (issue #164) like a first visit, on the built site: headed Chromium on the
// real GPU, a fresh browser context per run (no service worker, empty cache). Runs the "Finale: monitor"
// scenario: card + monitor, self-test, then QEMU with the Freedoom pack; measures the time from the
// scenario's power-on in QEMU mode to the first Freedoom frame on the monitor and the frame rate; with
// an output folder, takes screenshots (photoreal, x-ray) and a short frame sequence of the monitor.
//
//   node tools/qemu/finale-app.cjs http://127.0.0.1:47614/icicle-twin-site/ [runs] [shots-dir]
//
// Env: SETTLE_MS (how long Doom runs before the rate is read, default 20000), SMP, HEADLESS=1.
const path = require('node:path');
const fs = require('node:fs');
const { chromium } = require(path.resolve(__dirname, '../../node_modules/playwright'));

const url = process.argv[2] ?? 'http://127.0.0.1:47614/icicle-twin-site/';
const runs = Number(process.argv[3] ?? 1);
const out = process.argv[4] ?? '';
const settle = Number(process.env.SETTLE_MS ?? 20000);

async function once(run) {
  const browser = await chromium.launch({
    headless: process.env.HEADLESS === '1',
    args: ['--ignore-gpu-blocklist', '--enable-gpu'],
  });
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  const ready = () =>
    page.waitForFunction(() => document.documentElement.dataset.twinReady === 'true', null, {
      timeout: 120000,
    });
  await page.goto(url);
  await ready();
  const t0 = Date.now();
  await page.evaluate(() => window.__twin.bus.emit('scenario:run', { id: 'finale' }));
  // The first switch to QEMU mode reloads once for isolation; the finale resumes by itself.
  await page.waitForFunction(() => crossOriginIsolated === true, null, { timeout: 180000 });
  await ready();
  const tIsolated = Date.now() - t0;
  // Power-on in QEMU mode: the card says running.
  await page.waitForFunction(() => window.__qemu?.state === 'running', null, { timeout: 300000 });
  const tRunning = Date.now();
  await page.waitForFunction(() => window.__qemu.output[1].includes('1234:1111'), null, { timeout: 300000 });
  const tLspci = Date.now();
  await page.waitForFunction(() => window.__qemu.display().presented > 0, null, { timeout: 300000 });
  const tFirst = Date.now();
  const stats0 = await page.evaluate(() => window.__qemu.display());
  if (out && run === 1) {
    fs.mkdirSync(out, { recursive: true });
    await page.waitForTimeout(3000);
  }
  await page.waitForTimeout(settle);
  const stats = await page.evaluate(() => window.__qemu.display());
  // The page's own frame rate (requestAnimationFrame), which bounds what the monitor can show.
  const pageFps = await page.evaluate(
    () =>
      new Promise((resolve) => {
        let n = 0;
        const t0 = performance.now();
        const tick = () => {
          n++;
          if (performance.now() - t0 < 2000) requestAnimationFrame(tick);
          else resolve(Math.round((n * 10000) / (performance.now() - t0)) / 10);
        };
        requestAnimationFrame(tick);
      }),
  );
  const guestFps = await page.evaluate(() => {
    const m = [...window.__qemu.output[1].matchAll(/doomgeneric: (\d+) frames in ([\d.]+) s: ([\d.]+) fps/g)];
    return m.map((x) => Number(x[3]));
  });
  if (out && run === 1) {
    const monitor = async (name) => {
      // The monitor's picture as the trainee sees it: frame the camera on it, then shoot the canvas.
      await page.screenshot({ path: path.join(out, name) });
    };
    await page.evaluate(() => window.__twin.bus.emit('viewMode', 'photoreal'));
    await page.waitForTimeout(2500);
    await monitor('doom-photoreal.png');
    await page.evaluate(() => window.__twin.bus.emit('viewMode', 'xray'));
    await page.waitForTimeout(2500);
    await monitor('doom-xray.png');
    await page.evaluate(() => window.__twin.bus.emit('viewMode', 'photoreal'));
    await page.waitForTimeout(1500);
    // A short sequence of the frames themselves (what QEMU scanned out), as PNGs via a canvas.
    for (let i = 0; i < 6; i++) {
      const png = await page.evaluate(() => {
        const f = window.__twin.display.state().frame;
        if (!f) return null;
        const c = document.createElement('canvas');
        c.width = f.width;
        c.height = f.height;
        c.getContext('2d').putImageData(
          new ImageData(new Uint8ClampedArray(f.data), f.width, f.height),
          0,
          0,
        );
        return c.toDataURL('image/png');
      });
      if (png) fs.writeFileSync(path.join(out, `frame-${i}.png`), Buffer.from(png.split(',')[1], 'base64'));
      await page.waitForTimeout(1500);
    }
    fs.writeFileSync(path.join(out, 'console.txt'), await page.evaluate(() => window.__qemu.output[1]));
  }
  const r = {
    run,
    isolatedMs: tIsolated,
    runningToLspciMs: tLspci - tRunning,
    runningToFirstFrameMs: tFirst - tRunning,
    bridgeFirstFrameMs: stats0.firstFrameMs,
    fpsShown: stats.fps,
    pageFps,
    guestChangesPerS: stats.guestFps,
    presented: stats.presented,
    mode: stats.mode,
    guestFpsReports: guestFps,
    tray: await page.evaluate(() => {
      const p = window.__twin.host
        .latest()
        .peripherals.find((x) => x.instanceId === 'pcie-display-card@J6_PCIE');
      return p?.detail.summary;
    }),
    errors,
  };
  await browser.close();
  return r;
}

(async () => {
  for (let i = 1; i <= runs; i++) console.log(JSON.stringify(await once(i)));
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
