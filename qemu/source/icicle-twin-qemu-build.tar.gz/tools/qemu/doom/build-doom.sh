#!/usr/bin/env bash
# Build the Freedoom pack for the finale (issue #164): doomgeneric for riscv64 Linux (static, our fbdev
# platform layer doomgeneric_icicle.c), Freedoom 0.13.0 Phase 1 trimmed to what its attract mode plays,
# the start script, the licences, as one newc cpio that QEMU passes to Linux as its initrd. Runs in a
# throw-away ubuntu:24.04 container, like ../image/build-image.sh; downloads are sha256-pinned.
#
#   WORK=~/qemu-spike bash tools/qemu/doom/build-doom.sh
#
# Output: $WORK/out/freedoom-pack.cpio (+ doomgeneric.rv64, freedoom1-trimmed.wad for inspection)
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
WORK=${WORK:-$HOME/qemu-spike}
mkdir -p "$WORK/doom-dl" "$WORK/doom-build" "$WORK/out"
docker run --rm \
  -v "$HERE:/spec:ro" -v "$WORK/doom-dl:/dl" -v "$WORK/doom-build:/work" -v "$WORK/out:/out" \
  ubuntu:24.04 bash /spec/in-container.sh
ls -l "$WORK/out/freedoom-pack.cpio"
