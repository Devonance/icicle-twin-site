#!/usr/bin/env python3
"""The Freedoom pack for the twin's finale: a newc cpio archive that Linux unpacks over its built-in
initramfs when QEMU passes it as the initrd (-initrd). It holds doomgeneric, a trimmed Freedoom Phase 1
IWAD, the start script and the licences.

  python3 mkpack.py <doomgeneric binary> <freedoom1.wad> <S90freedoom> <docs dir> <out.cpio>

The IWAD keeps everything the attract mode uses: every graphic, texture, sprite, flat, the music, and
the four maps its demos play (DEMO1..DEMO4: E1M6, E2M4, E3M9, E4M6, read from the demo headers). The
other 32 maps keep their marker lump, empty (Doom tells Ultimate Doom from shareware by the markers),
and the sound effects (DS*, DP*) are left out: the twin has no sound. Freedoom is BSD-3-Clause, which
allows this; COPYING.txt and CREDITS.txt go with it.
"""
import os
import re
import struct
import sys

MAP_LUMPS = {'THINGS', 'LINEDEFS', 'SIDEDEFS', 'VERTEXES', 'SEGS', 'SSECTORS', 'NODES', 'SECTORS',
             'REJECT', 'BLOCKMAP', 'BEHAVIOR'}
MAP_RE = re.compile(r'^E\dM\d$|^MAP\d\d$')
RANGE_START = {'S_START', 'SS_START', 'F_START', 'FF_START', 'P_START', 'PP_START'}
RANGE_END = {'S_END', 'SS_END', 'F_END', 'FF_END', 'P_END', 'PP_END'}


def read_wad(data):
    ident, n, off = struct.unpack('<4sii', data[:12])
    if ident not in (b'IWAD', b'PWAD'):
        sys.exit('not a WAD')
    lumps = []
    for i in range(n):
        o, s, name = struct.unpack('<ii8s', data[off + 16 * i: off + 16 * i + 16])
        lumps.append((name.rstrip(b'\0').decode('latin1'), data[o:o + s]))
    return ident, lumps


def demo_maps(lumps):
    maps = set()
    for name, body in lumps:
        if re.match(r'^DEMO\d$', name) and len(body) >= 4:
            # Vanilla 1.9 demo header: version, skill, episode, map, ...
            maps.add(f'E{body[2]}M{body[3]}')
    return maps


def trim(lumps):
    keep_maps = demo_maps(lumps)
    out = []
    in_range = False
    current_map = None
    dropped = {'map lumps': 0, 'sound effects': 0}
    for name, body in lumps:
        if name in RANGE_START:
            in_range = True
        elif name in RANGE_END:
            in_range = False
        if MAP_RE.match(name):
            current_map = name
            out.append((name, body if name in keep_maps else b''))
            continue
        if current_map and name in MAP_LUMPS:
            if current_map in keep_maps:
                out.append((name, body))
            else:
                dropped['map lumps'] += len(body)
            continue
        current_map = None
        if not in_range and (name.startswith('DS') or name.startswith('DP')):
            dropped['sound effects'] += len(body)
            continue
        out.append((name, body))
    return out, keep_maps, dropped


def write_wad(ident, lumps):
    data = bytearray(12)
    directory = bytearray()
    for name, body in lumps:
        directory += struct.pack('<ii8s', len(data) if body else 0, len(body), name.encode('latin1'))
        data += body
    struct.pack_into('<4sii', data, 0, ident, len(lumps), len(data))
    return bytes(data + directory)


class Cpio:
    """newc (070701) writer: fixed owner root, fixed mtime, so the pack is reproducible."""

    def __init__(self):
        self.buf = bytearray()
        self.ino = 1000

    def _entry(self, name, mode, data=b''):
        self.ino += 1
        fields = [self.ino, mode, 0, 0, 2 if mode & 0o040000 else 1, 1767225600, len(data), 0, 0, 0, 0,
                  len(name) + 1, 0]
        self.buf += b'070701' + b''.join(b'%08X' % f for f in fields) + name.encode() + b'\0'
        self.buf += b'\0' * (-len(self.buf) % 4)
        self.buf += data
        self.buf += b'\0' * (-len(self.buf) % 4)

    def dir(self, name):
        self._entry(name, 0o040755)

    def file(self, name, data, mode=0o644):
        self._entry(name, 0o100000 | mode, data)

    def close(self):
        self._entry('TRAILER!!!', 0)
        self.buf += b'\0' * (-len(self.buf) % 512)
        return bytes(self.buf)


def main():
    if len(sys.argv) != 6:
        sys.exit(__doc__)
    doom, wad_path, script, docs, out = sys.argv[1:]
    ident, lumps = read_wad(open(wad_path, 'rb').read())
    trimmed, keep_maps, dropped = trim(lumps)
    wad = write_wad(ident, trimmed)
    print(f'freedoom1.wad: {os.path.getsize(wad_path)} -> {len(wad)} bytes; maps kept: '
          f'{", ".join(sorted(keep_maps))}; dropped {dropped["map lumps"]} bytes of map lumps, '
          f'{dropped["sound effects"]} bytes of sound effects')
    c = Cpio()
    for d in ('etc', 'etc/init.d', 'usr', 'usr/games', 'usr/share', 'usr/share/games',
              'usr/share/games/doom', 'usr/share/doc', 'usr/share/doc/freedoom', 'usr/share/doc/doomgeneric'):
        c.dir(d)
    c.file('etc/init.d/S90freedoom', open(script, 'rb').read(), 0o755)
    c.file('usr/games/doomgeneric', open(doom, 'rb').read(), 0o755)
    c.file('usr/share/games/doom/freedoom1.wad', wad)
    for name in sorted(os.listdir(docs)):
        sub = 'doomgeneric' if name.startswith('doomgeneric') else 'freedoom'
        c.file(f'usr/share/doc/{sub}/{name}', open(os.path.join(docs, name), 'rb').read())
    data = c.close()
    open(out, 'wb').write(data)
    print(f'{out}: {len(data)} bytes')


if __name__ == '__main__':
    main()
