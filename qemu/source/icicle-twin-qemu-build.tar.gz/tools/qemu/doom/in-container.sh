#!/usr/bin/env bash
# Runs inside ubuntu:24.04 (see build-doom.sh). /spec = this folder (ro), /dl = downloads, /work, /out.
set -euo pipefail
# doomgeneric (ozkl/doomgeneric, GPL-2.0): the commit Kevin's freedoom-mod engine uses.
DG_COMMIT=dcb7a8dbc7a16ce3dda29382ac9aae9d77d21284
DG_SHA256=1bd3f7f26220494159a38d71f2847ec81b58d6bbd7c7c8d81b08993018001148
# Freedoom 0.13.0 (BSD-3-Clause): the release zip; its freedoom1.wad is the one in freedoom-mod/engine/wad.
FD_VERSION=0.13.0
FD_SHA256=3f9b264f3e3ce503b4fb7f6bdcb1f419d93c7b546f4df3e874dd878db9688f59
WAD_SHA256=7323bcc168c5a45ff10749b339960e98314740a734c30d4b9f3337001f9e703d
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends gcc-riscv64-linux-gnu libc6-dev-riscv64-cross make python3 \
  curl ca-certificates unzip > /dev/null
dpkg-query -W -f '${Package} ${Version} ${Built-Using}\n' libc6-dev-riscv64-cross gcc-riscv64-linux-gnu \
  > /out/doom-toolchain.txt

cd /dl
[ -s "doomgeneric-$DG_COMMIT.tar.gz" ] ||
  curl -fLs -o "doomgeneric-$DG_COMMIT.tar.gz" "https://codeload.github.com/ozkl/doomgeneric/tar.gz/$DG_COMMIT"
got=$(sha256sum "doomgeneric-$DG_COMMIT.tar.gz" | cut -d' ' -f1)
if [ "$got" != "$DG_SHA256" ]; then echo "doomgeneric: sha256 $got, expected $DG_SHA256" >&2; exit 1; fi
[ -s "freedoom-$FD_VERSION.zip" ] ||
  curl -fLs -o "freedoom-$FD_VERSION.zip" \
    "https://github.com/freedoom/freedoom/releases/download/v$FD_VERSION/freedoom-$FD_VERSION.zip"
echo "$FD_SHA256  freedoom-$FD_VERSION.zip" | sha256sum -c --quiet -

cd /work
rm -rf "doomgeneric-$DG_COMMIT" "freedoom-$FD_VERSION" obj docs
tar xzf "/dl/doomgeneric-$DG_COMMIT.tar.gz"
unzip -q "/dl/freedoom-$FD_VERSION.zip"
echo "$WAD_SHA256  freedoom-$FD_VERSION/freedoom1.wad" | sha256sum -c --quiet -

# --- doomgeneric: upstream's Linux source list (Makefile.linuxvt) with our platform layer ---
SRC=/work/doomgeneric-$DG_COMMIT/doomgeneric
cp /spec/doomgeneric_icicle.c "$SRC/"
OBJS="dummy am_map doomdef doomstat dstrings d_event d_items d_iwad d_loop d_main d_mode d_net f_finale f_wipe
 g_game hu_lib hu_stuff info i_cdmus i_endoom i_joystick i_scale i_sound i_system i_timer memio m_argv m_bbox
 m_cheat m_config m_controls m_fixed m_menu m_misc m_random p_ceilng p_doors p_enemy p_floor p_inter p_lights
 p_map p_maputl p_mobj p_plats p_pspr p_saveg p_setup p_sight p_spec p_switch p_telept p_tick p_user r_bsp
 r_data r_draw r_main r_plane r_segs r_sky r_things sha1 sounds statdump st_lib st_stuff s_sound tables v_video
 wi_stuff w_checksum w_file w_main w_wad z_zone w_file_stdc i_input i_video doomgeneric mus2mid
 doomgeneric_icicle"
# 320 x 200: Doom's own resolution, no scaling in the guest (the monitor scales). -O2 as freedoom-mod.
CFLAGS="-O2 -w -std=gnu11 -fno-strict-aliasing -DNORMALUNIX -DLINUX -D_DEFAULT_SOURCE \
 -DDOOMGENERIC_RESX=320 -DDOOMGENERIC_RESY=200 -ffunction-sections -fdata-sections"
mkdir -p obj
for o in $OBJS; do riscv64-linux-gnu-gcc $CFLAGS -c "$SRC/$o.c" -o "obj/$o.o" & done
wait
riscv64-linux-gnu-gcc -static -Wl,--gc-sections -o doomgeneric.rv64 obj/*.o -lm
riscv64-linux-gnu-strip doomgeneric.rv64
cp doomgeneric.rv64 /out/doomgeneric.rv64

# --- licences and notes that go into the pack (/usr/share/doc) ---
mkdir -p docs
cp "freedoom-$FD_VERSION/COPYING.txt" docs/COPYING.txt
cp "freedoom-$FD_VERSION/CREDITS.txt" docs/CREDITS.txt
cp "doomgeneric-$DG_COMMIT/LICENSE" docs/doomgeneric-LICENSE.txt 2>/dev/null ||
  cp "doomgeneric-$DG_COMMIT/doomgeneric/LICENSE" docs/doomgeneric-LICENSE.txt
cat > docs/README.txt <<EOF
Freedoom pack of the Icicle Twin's finale (issue #164), unpacked over the built-in initramfs.

/usr/games/doomgeneric      doomgeneric (https://github.com/ozkl/doomgeneric, commit $DG_COMMIT, GPL-2.0)
                            with doomgeneric_icicle.c (GPL-2.0, from doomgeneric_linuxvt.c): draws on
                            /dev/fb0, no input, attract mode. Source: the site's qemu/source/.
/usr/share/games/doom/freedoom1.wad
                            Freedoom $FD_VERSION Phase 1 (https://freedoom.github.io, BSD-3-Clause, see
                            COPYING.txt and CREDITS.txt), trimmed: the four maps its demos play
                            (E1M6, E2M4, E3M9, E4M6) and every graphic and music lump; the other maps
                            keep only their (empty) marker lump and the sound effects are left out.
/etc/init.d/S90freedoom     starts it at boot when /dev/fb0 exists.
EOF
python3 /spec/mkpack.py doomgeneric.rv64 "freedoom-$FD_VERSION/freedoom1.wad" /spec/S90freedoom docs \
  /out/freedoom-pack.cpio
ls -l /out/freedoom-pack.cpio /out/doomgeneric.rv64
