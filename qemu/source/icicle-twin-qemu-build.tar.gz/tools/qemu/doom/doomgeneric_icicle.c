// SPDX-License-Identifier: GPL-2.0-only
//
// doomgeneric platform layer for the Icicle Twin's finale (issue #164): Linux on QEMU's
// microchip-icicle-kit, drawing on /dev/fb0, the fbdev emulation of bochs-drm for the PCIe display
// card in J6. No input: Doom runs its attract mode (title screen and the IWAD's demos) by itself.
//
// Based on doomgeneric_linuxvt.c (doomgeneric, "doomgeneric for a bare Linux VirtualTerminal",
// Copyright (C) 2025 Techflash, GPL-2.0), with the keyboard part removed and frames written with
// pwrite() instead of a mmap of the framebuffer: bochs-drm's fbdev is a shadow buffer, and a
// write() marks the damage at once, while writes through a mapping are collected by deferred I/O
// (about 20 times a second). It also prints its own frame rate on the console now and then.

#include "doomgeneric.h"
#include "i_system.h"

#include <errno.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#define ROW_BYTES (DOOMGENERIC_RESX * 4)
#define REPORT_MS 15000

static int fb_fd = -1;
static unsigned fb_stride, fb_x, fb_y;
static int fb_whole; // the picture is the whole framebuffer: one write per frame
static struct timespec t0;
static uint32_t frames, report_at, report_frames;

static uint32_t now_ms(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint32_t)((t.tv_sec - t0.tv_sec) * 1000 + (t.tv_nsec - t0.tv_nsec) / 1000000);
}

void DG_Init(void)
{
    struct fb_var_screeninfo v;
    struct fb_fix_screeninfo f;

    clock_gettime(CLOCK_MONOTONIC, &t0);
    fb_fd = open("/dev/fb0", O_RDWR);
    if (fb_fd < 0)
        I_Error("doomgeneric: cannot open /dev/fb0: %s", strerror(errno));
    if (ioctl(fb_fd, FBIOGET_VSCREENINFO, &v) != 0 || ioctl(fb_fd, FBIOGET_FSCREENINFO, &f) != 0)
        I_Error("doomgeneric: /dev/fb0 info: %s", strerror(errno));
    if (v.bits_per_pixel != 32)
        I_Error("doomgeneric: /dev/fb0 is %u bits per pixel; this port draws 32", v.bits_per_pixel);
    if (v.xres < DOOMGENERIC_RESX || v.yres < DOOMGENERIC_RESY)
        I_Error("doomgeneric: /dev/fb0 is %ux%u, smaller than %ux%u", v.xres, v.yres,
                DOOMGENERIC_RESX, DOOMGENERIC_RESY);
    // Without fbcon nobody has set the mode on the card yet: DRM's fbdev emulation does the modeset
    // (bochs-drm writes the DISPI registers, scan-out starts) when the mode is set or the screen unblanked.
    v.activate = FB_ACTIVATE_NOW | FB_ACTIVATE_FORCE;
    if (ioctl(fb_fd, FBIOPUT_VSCREENINFO, &v) != 0)
        printf("doomgeneric: FBIOPUT_VSCREENINFO: %s\n", strerror(errno));
    if (ioctl(fb_fd, FBIOBLANK, FB_BLANK_UNBLANK) != 0)
        printf("doomgeneric: FBIOBLANK: %s\n", strerror(errno));
    if (ioctl(fb_fd, FBIOGET_FSCREENINFO, &f) != 0)
        I_Error("doomgeneric: /dev/fb0 info: %s", strerror(errno));
    fb_stride = f.line_length;
    fb_x = (v.xres - DOOMGENERIC_RESX) / 2 * 4;
    fb_y = (v.yres - DOOMGENERIC_RESY) / 2;
    fb_whole = fb_x == 0 && fb_stride == ROW_BYTES;
    printf("doomgeneric: /dev/fb0 \"%s\" %ux%u, %u bpp, %u bytes per line, %u KiB\n", f.id, v.xres,
           v.yres, v.bits_per_pixel, fb_stride, f.smem_len / 1024);
    // Clear the screen (the margins stay black).
    uint8_t *zero = calloc(1, fb_stride);
    for (unsigned y = 0; zero && y < v.yres; y++)
        if (pwrite(fb_fd, zero, fb_stride, (off_t)y * fb_stride) < 0)
            break;
    free(zero);
    report_at = REPORT_MS;
}

void DG_DrawFrame(void)
{
    // DG_ScreenBuffer is 0x00RRGGBB per pixel: XRGB8888, the fbdev's format.
    if (fb_whole) {
        if (pwrite(fb_fd, DG_ScreenBuffer, ROW_BYTES * DOOMGENERIC_RESY, (off_t)fb_y * fb_stride) < 0)
            I_Error("doomgeneric: write /dev/fb0: %s", strerror(errno));
    } else {
        for (int y = 0; y < DOOMGENERIC_RESY; y++)
            if (pwrite(fb_fd, (uint8_t *)DG_ScreenBuffer + y * ROW_BYTES, ROW_BYTES,
                       (off_t)(fb_y + y) * fb_stride + fb_x) < 0)
                I_Error("doomgeneric: write /dev/fb0: %s", strerror(errno));
    }
    frames++;
    uint32_t t = now_ms();
    if (t >= report_at) {
        uint32_t span = t - (report_at - REPORT_MS);
        printf("doomgeneric: %u frames in %.1f s: %.1f fps (guest clock)\n", frames - report_frames,
               span / 1000.0, (frames - report_frames) * 1000.0 / (span ? span : 1));
        fflush(stdout);
        report_frames = frames;
        report_at = t + REPORT_MS;
    }
}

void DG_SleepMs(uint32_t ms)
{
    usleep(ms * 1000);
}

uint32_t DG_GetTicksMs(void)
{
    return now_ms();
}

int DG_GetKey(int *pressed, unsigned char *key)
{
    (void)pressed;
    (void)key;
    return 0; // no keyboard: attract mode
}

void DG_SetWindowTitle(const char *title)
{
    printf("doomgeneric: %s\n", title);
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IOLBF, 0);
    doomgeneric_Create(argc, argv);
    for (;;)
        doomgeneric_Tick();
    return 0;
}
