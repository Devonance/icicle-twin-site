#!/usr/bin/env bash
# Build qemu-system-riscv64 for WebAssembly (Emscripten 3.1.50, wasm32, TCG->Wasm JIT + TCI)
# from ktock/qemu-wasm, pinned, with our patches. Runs on Linux (WSL2 is fine) with Docker.
#
#   WORK=~/qemu-spike bash tools/qemu/build-qemu-wasm.sh          # first build (~10 min on 32 cores)
#   WORK=~/qemu-spike bash tools/qemu/build-qemu-wasm.sh          # again: incremental
#   CLEAN=1 WORK=~/qemu-spike bash tools/qemu/build-qemu-wasm.sh  # fresh container + configure
#   CONTAINER=build-qemu-wasm-x WORK=~/x bash tools/qemu/build-qemu-wasm.sh  # a second tree beside the first
#
# Output: $WORK/out/qemu-system-riscv64.{js,wasm,worker.js}, opensbi fw_dynamic.
# The source tree and the build stay on the Linux filesystem ($WORK); building from /mnt/c is very slow.
set -euo pipefail

QEMU_WASM_REPO=https://github.com/ktock/qemu-wasm
QEMU_WASM_COMMIT=0ef7b4e2814b231705d8371dd7997f5b72e70baf   # master 2025-09-04 (PR #36); QEMU 8.2.0 base
WORK=${WORK:-$HOME/qemu-spike}
HERE=$(cd "$(dirname "$0")" && pwd)
SRC=$WORK/src/qemu-wasm
# The build container keeps the build directory (/build); one per $WORK tree.
CONTAINER=${CONTAINER:-build-qemu-wasm}
IMAGE=${IMAGE:-buildqemu}
mkdir -p "$WORK/src" "$WORK/out"

if [ -n "${CLEAN_SRC:-}" ]; then rm -rf "$SRC"; fi
if [ ! -d "$SRC/.git" ]; then
  git init -q "$SRC"
  git -C "$SRC" fetch -q --depth 1 "$QEMU_WASM_REPO" "$QEMU_WASM_COMMIT"
  git -C "$SRC" checkout -q FETCH_HEAD
fi
# Our patches (tools/qemu/patches/*.patch, applied in order). $SRC/.icicle-twin-patches records each
# applied patch with its hash, so a rerun skips it; a patch edited since it was applied needs a fresh
# tree (CLEAN_SRC=1).
STAMP=$SRC/.icicle-twin-patches
touch "$STAMP"
for p in "$HERE"/patches/*.patch; do
  [ -e "$p" ] || continue
  name=$(basename "$p")
  id="$name $(sha256sum < "$p" | cut -c1-16)"
  if grep -qxF "$id" "$STAMP"; then
    echo "already applied $name"
  elif grep -q "^$name " "$STAMP"; then
    echo "$name changed since it was applied: rerun with CLEAN_SRC=1" >&2; exit 1
  elif git -C "$SRC" apply --check "$p" 2>/dev/null; then
    git -C "$SRC" apply "$p"; echo "$id" >> "$STAMP"; echo "applied $name"
  elif git -C "$SRC" apply --reverse --check "$p" 2>/dev/null; then
    echo "$id" >> "$STAMP"; echo "already applied $name"
  else
    echo "FAILED to apply $name (CLEAN_SRC=1 starts from a fresh tree)" >&2; exit 1
  fi
done

# Toolchain image: Emscripten 3.1.50 + glib 2.75 / zlib / libffi / pixman built for wasm32.
docker image inspect "$IMAGE" >/dev/null 2>&1 || docker build -t "$IMAGE" - < "$HERE/Dockerfile.toolchain"

if [ -n "${CLEAN:-}" ]; then docker rm -f "$CONTAINER" >/dev/null 2>&1 || true; fi
if [ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null)" != true ]; then
  docker rm -f "$CONTAINER" >/dev/null 2>&1 || true
  docker run --rm -d --name "$CONTAINER" -v "$SRC:/qemu/" "$IMAGE" >/dev/null
fi

# The qemu-wasm README's flags, except: no -g (smaller .wasm); 1 GiB heap (guest RAM is 256 MiB); no
# xterm-pty js-library (the console is the shared-memory ring chardev from our patch, not stdio);
# HEAPU8/HEAPU32 exported so the page can read the console rings and the GPIO2 window.
EXTRA_CFLAGS="-O3 -Wno-error=unused-command-line-argument -matomics -mbulk-memory -DNDEBUG -DG_DISABLE_ASSERT \
 -D_GNU_SOURCE -sASYNCIFY=1 -pthread -sPROXY_TO_PTHREAD=1 -sFORCE_FILESYSTEM -sALLOW_TABLE_GROWTH \
 -sTOTAL_MEMORY=${TOTAL_MEMORY:-1024MB} -sWASM_BIGINT -sMALLOC=mimalloc \
 -sEXPORT_ES6=1 -sASYNCIFY_IMPORTS=ffi_call_js"

if ! docker exec "$CONTAINER" test -f /build/build.ninja; then
  docker exec "$CONTAINER" emconfigure /qemu/configure --static --target-list=riscv64-softmmu --cpu=wasm32 \
    --cross-prefix= --without-default-features --enable-system --with-coroutine=fiber \
    --extra-cflags="$EXTRA_CFLAGS" --extra-cxxflags="$EXTRA_CFLAGS" \
    --extra-ldflags="-sEXPORTED_RUNTIME_METHODS=getTempRet0,setTempRet0,addFunction,removeFunction,FS,HEAPU8,HEAPU32"
fi
docker exec "$CONTAINER" emmake make -j "$(nproc)" qemu-system-riscv64

docker cp "$CONTAINER":/build/qemu-system-riscv64 "$WORK/out/qemu-system-riscv64.js"
for f in qemu-system-riscv64.wasm qemu-system-riscv64.worker.js; do
  docker cp "$CONTAINER:/build/$f" "$WORK/out/$f"
done
# OpenSBI fw_dynamic (BSD-2-Clause) from QEMU's pc-bios: the firmware for direct kernel boot.
cp "$SRC/pc-bios/opensbi-riscv64-generic-fw_dynamic.bin" "$WORK/out/"
ls -l "$WORK/out"
