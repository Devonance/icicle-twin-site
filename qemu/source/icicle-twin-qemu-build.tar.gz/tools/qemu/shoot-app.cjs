// Screenshots of the app's "Real CPU (QEMU)" mode for docs/shots/qemu-1 (headed Chromium, real GPU):
// the card, real Linux on COM B running blinky with LED1..LED4 on the photoreal board, and the x-ray.
//
//   node tools/qemu/shoot-app.cjs http://127.0.0.1:47613/ docs/shots/qemu-1
const path = require('node:path');
const { chromium } = require(path.resolve(__dirname, '../../node_modules/playwright'));

const url = process.argv[2] ?? 'http://127.0.0.1:47613/';
const out = process.argv[3] ?? 'docs/shots/qemu-1';

(async () => {
  const browser = await chromium.launch({ headless: false, args: ['--ignore-gpu-blocklist', '--enable-gpu'] });
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
  const shot = (name) => page.screenshot({ path: path.join(out, name) });
  const twin = (fn, arg) => page.evaluate(fn, arg);
  await page.goto(url);
  await page.waitForFunction(() => document.documentElement.dataset.twinReady === 'true', null, { timeout: 90000 });
  await twin(() => window.__twin.bus.emit('viewMode', 'photoreal'));
  await page.waitForTimeout(3000);
  await page.click('.tw-pill-engine');
  await page.waitForTimeout(500);
  await shot('card.png');
  await page.click('.tw-qemu-start');
  await page.waitForFunction(() => crossOriginIsolated && window.__qemu?.state === 'held' && window.__qemu.timings.downloaded !== undefined, null, {
    timeout: 120000,
  });
  await twin(() => window.__twin.bus.emit('viewMode', 'photoreal'));
  await page.waitForTimeout(2000);
  await shot('held.png');
  await twin(() => {
    const h = window.__twin.host;
    h.send({ type: 'plug', peripheral: 'usb-uart-cable', socket: 'J11_USB' });
    h.send({ type: 'power', connected: true });
    h.send({ type: 'switch', id: 'SW6', position: 'on' });
  });
  await page.waitForFunction(() => window.__qemu.state === 'running', null, { timeout: 120000 });
  await page.waitForFunction(() => document.querySelector('twin-terminal')?.linkState === 'connected', null, { timeout: 120000 });
  const box = await page.locator('twin-terminal').boundingBox();
  await page.mouse.click(box.x + box.width / 2, box.y + box.height - 30);
  await page.waitForFunction(() => window.__qemu.output[1].includes('login:'), null, { timeout: 120000 });
  await page.keyboard.type('root\n', { delay: 40 });
  await page.waitForFunction(() => window.__qemu.output[1].endsWith('Password: '), null, { timeout: 30000 });
  await page.keyboard.type('microchip\n', { delay: 40 });
  await page.waitForFunction(() => window.__qemu.output[1].includes('root@icicle-kit-es:~#'), null, { timeout: 30000 });
  await page.keyboard.type('blinky -p 700\n', { delay: 30 });
  await page.locator('.tw-info-toggle').first().click().catch(() => undefined); // fold the info card
  await twin(() => window.__twin.bus.emit('view:focus', { id: 'qemu-1', target: 'LED2' }));
  await page.waitForTimeout(3000);
  // Wait for a frame where LED3 (amber) is lit, so the shot shows a lit user LED.
  const waitLed = (r) =>
    page.waitForFunction((ref) => window.__twin.host.latest()?.leds[ref]?.on === true, r, { timeout: 10000, polling: 30 });
  await waitLed('LED3');
  await page.waitForTimeout(150);
  await shot('blinky-photoreal.png');
  await twin(() => window.__twin.bus.emit('viewMode', 'xray'));
  await page.waitForTimeout(1500);
  await waitLed('LED1');
  await page.waitForTimeout(150);
  await shot('blinky-xray.png');
  // The LEDs alone, without the terminal.
  await twin(() => window.__twin.bus.emit('panel', { id: 'terminal', open: false }));
  await twin(() => window.__twin.bus.emit('viewMode', 'photoreal'));
  await twin(() => window.__twin.bus.emit('view:focus', { id: 'qemu-2', target: 'LED2' }));
  await page.waitForTimeout(2500);
  await waitLed('LED4');
  await page.waitForTimeout(150);
  await shot('leds-closeup.png');
  await twin(() => window.__twin.bus.emit('panel', { id: 'terminal', open: true }));
  await page.waitForTimeout(500);
  await page.mouse.click(box.x + box.width / 2, box.y + box.height - 30);
  await page.keyboard.press('Control+c');
  await page.waitForTimeout(500);
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
