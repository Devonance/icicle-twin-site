#!/usr/bin/env bash
# Native (x86-64 Linux) build of the same patched qemu-wasm tree, as a baseline: it checks the guest
# image without a browser and gives the native boot time to compare with the wasm build.
# Run build-qemu-wasm.sh first (it clones, patches and fetches the dtc subproject).
#
#   WORK=~/qemu-spike bash tools/qemu/build-qemu-native.sh
#
# Output: $WORK/native/build/qemu-system-riscv64
set -euo pipefail
WORK=${WORK:-$HOME/qemu-spike}
mkdir -p "$WORK/native"
docker run --rm -v "$WORK/src/qemu-wasm:/qemu:ro" -v "$WORK/native:/native" ubuntu:24.04 bash -c '
  set -e
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq --no-install-recommends build-essential python3 python3-venv ninja-build pkg-config \
    libglib2.0-dev libpixman-1-dev flex bison git ca-certificates > /dev/null
  mkdir -p /native/build && cd /native/build
  [ -f build.ninja ] && grep -q ucontext config-host.h 2>/dev/null || /qemu/configure --target-list=riscv64-softmmu --without-default-features --enable-system \
    --enable-tcg --with-coroutine=ucontext --disable-werror > /dev/null
  ninja -j"$(nproc)" -k 0 qemu-system-riscv64 2>&1 | grep -E -A3 "error|FAILED" | head -40
  ls -l qemu-system-riscv64
'
